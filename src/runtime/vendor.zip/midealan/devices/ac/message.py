"""Midea AC message."""

import logging
from collections.abc import Callable, Mapping
from enum import IntEnum
from types import MappingProxyType

from midealan.const import MAX_BYTE_VALUE, DeviceType
from midealan.crc8 import calculate
from midealan.message import (
    ListTypes,
    MessageBody,
    MessageRequest,
    MessageResponse,
    MessageType,
    NewProtocolMessageBody,
)

_LOGGER = logging.getLogger(__name__)

# A decoded B5 capability value. Most tags decode to a bool/int flag, but some
# tags decode to a nested map. The temperature tag yields a per-mode setpoint
# limit map, keyed "cool"/"auto"/"heat" with "min"/"max" floats plus a
# "decimals" bool. The mode tag yields a supported-modes map, keyed
# "heat"/"cool"/"dry"/"auto" with bool values. The wind_swing tag yields a
# supported-swing map, keyed "horizontal"/"vertical" with bool values. The
# wind_speed tag yields a supported-fan-speed map, keyed
# "silent"/"low"/"medium"/"high"/"auto"/"custom" with bool values.
CapabilityValue = bool | int | list[str] | dict[str, dict[str, float] | bool]

BB_AC_MODES = [0, 3, 1, 2, 4, 5]
BB_MIN_BODY_LENGTH = 21
BB_FRESH_AIR_SWITCH_INDEX = 45
BB_FRESH_AIR_INTAKE_STATUS_MASK = 0x01
BB_FRESH_AIR_EXHAUST_STATUS_MASK = 0x02
BB_FRESH_AIR_INTAKE_SPEED_INDEX = 46
BB_FRESH_AIR_EXHAUST_SPEED_INDEX = 47
BB_COMPRESSOR_TARGET_FREQUENCY_INDEX = 10
BB_COMPRESSOR_FREQUENCY_INDEX = 11
BB_BASIC_FAN_SPEED_INDEX = 7
BB_INDOOR_TEMPERATURE_HIGH_INDEX = 8
BB_INDOOR_HUMIDITY_INDEX = 30
BB_SN8_FLAG_INDEX = 80
BB_OUTDOOR_TEMPERATURE_HIGH_INDEX = 6

A0_A1_C0_MIN_BODY_LENGTH = 18
CONFORT_MODE_MIN_LENGTH2 = 25
SMART_DRY_MIN_LENGTH = 22
SWING_LR_MIN_LENGTH = 22
FRESH_AIR_C0_MIN_LENGTH = 30
ECO_MODE_MIN_SUBPROTOCOL_LENGTH = 27
FRESH_AIR_LENGTH = 2
FROST_PROTECT_MIN_LENGTH = 24
INDIRECT_WIND_VALUE = 0x02
MAX_MSG_SERIAL_NUM = 254
# Outdoor Silent uses a model-specific activation value and 0x00 to deactivate:
# - 0x02: https://github.com/wuwentao/midea_ac_lan/issues/1128
# - 0x03: https://github.com/wuwentao/midea_ac_lan/issues/779
# Keep 0x03 as the fallback for devices without a numeric B5 capability value.
DEFAULT_OUT_SILENT_VALUE = 0x03
OUT_SILENT_OFF_VALUE = 0x00
POWER_SAVING_VALUE = 0x08
SCREEN_DISPLAY_BYTE_CHECK = 0x07
SUB_PROTOCOL_BODY_TEMP_CHECK = 0x80
TEMP_DECIMAL_MIN_BODY_LENGTH = 20
TIMER_MIN_SUBPROTOCOL_LENGTH = 27
XBB_SN8_BYTE_FLAG = 0x31
XC1_SUBBODY_TYPE_40 = 0x40
XC1_SUBBODY_TYPE_41 = 0x41
XC1_SUBBODY_TYPE_42 = 0x42
XC1_SUBBODY_TYPE_44 = 0x44
XC1_SUBBODY_TYPE_45 = 0x45
XC1_SUBBODY_TYPE_47 = 0x47
XC1_SUBBODY_TYPE_INDEX = 3
XC1_HUMIDITY_INDEX = 4
# Group 5 byte 10 is non-zero while the outdoor unit is defrosting (heat mode).
XC1_DEFROST_INDEX = 10
XC1_CONSUMPTION_MIN_LENGTH = 19
XC1_OPERATING_TIME_MIN_LENGTH = 19

# Group data query: the third payload byte selects the group, 0x40 | group number.
XC1_GROUP_QUERY_BASE = 0x40
# Minimum body length required to parse each group data response.
XC1_GROUP_ONE_MIN_LENGTH = 15
XC1_GROUP_TWO_MIN_LENGTH = 9
XC1_GROUP_SEVEN_MIN_LENGTH = 12
# Refrigerant circuit temperatures are reported as half degrees with an offset:
# T1/T2 (indoor ambient / indoor coil) use 30, T3/T4 (outdoor coil / ambient) use 50.
XC1_TEMP_INDOOR_OFFSET = 30
XC1_TEMP_OUTDOOR_OFFSET = 50
XC1_TEMP_DIVISOR = 2
# Indoor fan speed is reported in units of 8 RPM.
XC1_FAN_SPEED_FACTOR = 8
# Bit 4 of group 2 byte 8 indicates the condensate water pump is running.
XC1_WATER_PUMP_MASK = 0x10

BB_FRESH_AIR_CONTROL_BODY_LENGTH = 96
BB_FRESH_AIR_CONTROL_CURSOR = 15
BB_FRESH_AIR_INTAKE_SWITCH_MASK = 0x04
BB_FRESH_AIR_EXHAUST_SWITCH_MASK = 0x08
BB_FRESH_AIR_INTAKE_CONTROL_SPEED_INDEX = 55
BB_FRESH_AIR_EXHAUST_CONTROL_SPEED_INDEX = 56
BB_FRESH_AIR_SPEED_FLAG = 0x80

# Model 22013279 reports temperatures in this new-protocol tag because its
# standard C0 temperature fields are stale.
NEW_PROTOCOL_TEMPERATURE_TAG = 0x7E
NEW_PROTOCOL_TEMPERATURE_MIN_LENGTH = 41
NEW_PROTOCOL_SETPOINT_OFFSET = 11.5
NEW_PROTOCOL_SETPOINT_MASK = 0x3F
NEW_PROTOCOL_SETPOINT_HALF_DEGREE_BIT = 0x40
NEW_PROTOCOL_MIN_VALID_TEMPERATURE = 10
NEW_PROTOCOL_MAX_VALID_TEMPERATURE = 40
NEW_PROTOCOL_LEGACY_SETPOINT_BYTE = 3
NEW_PROTOCOL_INDOOR_TEMPERATURE_BYTE = 40
NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE = 41
NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_MASK = 0x0F
# Live degerming (sterilize) state rides the 0x7e new-protocol payload on
# verified hardware: byte 19, bit 0x02. Reported in both B0/B1 bodies and B5
# notify bodies, unlike self_clean whose B5 occurrence is only a capability
# flag. Verified on model 22019053 / protocol v3 with device-side toggles.
NEW_PROTOCOL_DEGERMING_BYTE = 19
NEW_PROTOCOL_DEGERMING_MASK = 0x02
# Light sensitivity and the countdown timer slots ride the same 0x7e payload on
# the same verified hardware: light sensitivity is a 2-bit field (0 = off,
# 3 = on; the intermediate levels 1/2 exist but are not characterized yet) and
# the countdown timers are two independent slots, power-on and power-off. The
# high bit is the armed flag, the lower bits carry hours plus quarter-hours,
# and byte 6 carries per-slot minute correction nibbles. The indexes below are
# offsets into the parsed 0x7e payload as exposed by the parser (payload[0] is
# the leading seq/flag byte, so raw payload byte N sits at index N + 1 - the
# same convention as NEW_PROTOCOL_DEGERMING_BYTE).
NEW_PROTOCOL_LIGHT_SENSITIVE_BYTE = 23
NEW_PROTOCOL_LIGHT_SENSITIVE_MASK = 0xC0
NEW_PROTOCOL_POWER_ON_TIMER_BYTE = 4
NEW_PROTOCOL_POWER_OFF_TIMER_BYTE = 5
NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_BYTE = 6
NEW_PROTOCOL_TIMER_ARMED_MASK = 0x80
NEW_PROTOCOL_TIMER_VALUE_MASK = 0x7F
NEW_PROTOCOL_TIMER_HOUR_SHIFT = 2
NEW_PROTOCOL_TIMER_QUARTER_MASK = 0x03
NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MASK = 0x0F
NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MAX = 15
NEW_PROTOCOL_TIMER_MINUTES_PER_HOUR = 60
NEW_PROTOCOL_TIMER_MINUTES_PER_QUARTER = 15
NEW_PROTOCOL_TIMER_POWER_ON_CORRECTION_SHIFT = 4
# The C0 status body carries the same countdown slots as the 0x7e payload, at
# body bytes 4 (power-on), 5 (power-off) and 6 (minute nibbles), per the vendor
# fixed-header Lua (e.g. T_0000_AC_00000Q11_2024013001.lua). The
# NEW_PROTOCOL_TIMER_* slot constants above apply to both, and to the same
# slots in the X40 (StateSet) body. The vendor app always sets
# COUNTDOWN_TIMER_SET_FLAG in the X40 fan byte; 0x7F, or any slot byte without
# bit 7 (e.g. the default 00), disarms that slot.
C0_POWER_ON_TIMER_BYTE = 4
C0_POWER_OFF_TIMER_BYTE = 5
C0_TIMER_MINUTE_CORRECTION_BYTE = 6
COUNTDOWN_TIMER_SET_FLAG = 0x80
COUNTDOWN_TIMER_SLOT_DISARMED = 0x7F
# Bit 7 of a slot byte is the armed flag, which leaves 5 hour bits (31 h),
# 3 quarter-hours and up to 14 minutes from the nibble.
COUNTDOWN_TIMER_MAX_MINUTES = 31 * 60 + 59
# B0 (PropertiesSet) timer parameters: [switch, hours, minutes], per
# T_0000_AC_22019053_2024012501.lua.
PROPERTIES_TIMER_SWITCH_ON = 0x01
PROPERTIES_TIMER_SWITCH_OFF = 0x00
# Live self-clean state is carried by the same payload (byte 8 bit 2).
NEW_PROTOCOL_SELF_CLEAN_BYTE = 8
NEW_PROTOCOL_SELF_CLEAN_MASK = 0x04
# Live state bytes riding the same 0x7e new-protocol payload: power / mode /
# fan-speed at bytes 1 / 2 / 3 (identical encoding to the C0/A0 state
# bodies), indirect wind (prevent straight wind) at byte 14 bit 0x40 and
# indoor humidity at byte 36. Verified against HA state history on model
# 22019061, 2026-10-08 (59 notify frames plus B1/B5 reconciliation).
NEW_PROTOCOL_POWER_BYTE = 1
NEW_PROTOCOL_POWER_MASK = 0x01
NEW_PROTOCOL_MODE_BYTE = 2
NEW_PROTOCOL_MODE_MASK = 0xE0
NEW_PROTOCOL_MODE_SHIFT = 5
NEW_PROTOCOL_FAN_SPEED_BYTE = 3
NEW_PROTOCOL_FAN_SPEED_MASK = 0x7F
NEW_PROTOCOL_INDIRECT_WIND_BYTE = 14
NEW_PROTOCOL_INDIRECT_WIND_MASK = 0x40
NEW_PROTOCOL_INDOOR_HUMIDITY_BYTE = 36
NEW_PROTOCOL_INDOOR_HUMIDITY_MAX = 100
# Live swing flags and fixed louver angles ride the same 0x7e payload: the
# swing flags share the bit layout of the XA0/State bodies (byte 7: vertical
# 0x0C / horizontal 0x03) and the louver angles sit in byte 17 (high nibble =
# left-right, low nibble = up-down). The vendor Lua maps angle nibbles 2-9
# onto the 100-based grades {13, 25, 38, 50, 62, 75, 88, 100}; nibbles 0/1
# pass through unchanged. Only grades that the library angle maps
# (_wind_lr_angles / _wind_ud_angles) can express are written; the
# intermediate grades are skipped. Verified against the vendor Lua
# read-side segments of models 22019061 / 22019053 (swing flags at
# cursor+11; louver angles at cursor+21, plus a same-table direct-index
# variant) and HA state history on model 22019061, 2026-10-08.
NEW_PROTOCOL_SWING_BYTE = 7
NEW_PROTOCOL_SWING_VERTICAL_MASK = 0x0C
NEW_PROTOCOL_SWING_HORIZONTAL_MASK = 0x03
NEW_PROTOCOL_WIND_ANGLE_BYTE = 17
NEW_PROTOCOL_WIND_LR_ANGLE_SHIFT = 4
NEW_PROTOCOL_WIND_UD_ANGLE_MASK = 0x0F
NEW_PROTOCOL_WIND_ANGLE_GRADES: dict[int, int] = {
    0: 0,
    1: 1,
    2: 13,
    3: 25,
    4: 38,
    5: 50,
    6: 62,
    7: 75,
    8: 88,
    9: 100,
}
# Mirrors the keys of MideaACDevice._wind_lr_angles / _wind_ud_angles.
NEW_PROTOCOL_WIND_ANGLE_LIB_GRADES: frozenset[int] = frozenset(
    {0, 1, 25, 50, 75, 100},
)
# Generic branch of the 0x7e temperature payload (identical encoding to the
# XA0 state body): setpoint = bits 1-5 + 12.0 (+0.5 when bit 0x40 is set);
# indoor temperature = bytes 40/41. Read dual-path: the C0/A0/A1 sources
# keep updating these attributes as well (no latch).
NEW_PROTOCOL_GENERIC_SETPOINT_MASK = 0x3E
NEW_PROTOCOL_GENERIC_SETPOINT_SHIFT = 1
NEW_PROTOCOL_GENERIC_SETPOINT_OFFSET = 12.0
NEW_PROTOCOL_GENERIC_SETPOINT_HALF_DEGREE_BIT = 0x40
NEW_PROTOCOL_GENERIC_SETPOINT_HALF_DEGREE_STEP = 0.5

# X40 set packets carry low targets in a legacy extension byte.
LOW_TARGET_TEMPERATURE_BOUNDARY = 17.0
LOW_TARGET_TEMPERATURE_OFFSET = 12
LOW_TARGET_TEMPERATURE_MASK = 0x1F
LOW_TARGET_C0_EXTENSION_INDEX = 13
LOW_TARGET_C0_EXTENSION_VALUE = 4
LOW_TARGET_C0_STANDARD_MAX = LOW_TARGET_TEMPERATURE_BOUNDARY + 0.5

# Capability value semantics (reverse-engineered; see _parse_capabilities).
# The raw byte of each capability is not a 0/1 flag; each has its own value set.
B5_HEAT_MODE_VALUES = frozenset({1, 2, 4, 6, 7, 9, 10, 11, 12, 13})
B5_NO_COOL_MODE_VALUES = frozenset({2, 10, 12})
B5_DRY_MODE_VALUES = frozenset({0, 1, 5, 6, 9, 11, 13})
B5_AUTO_MODE_VALUES = frozenset({0, 1, 2, 7, 8, 9, 13})
B5_SWING_HORIZONTAL_VALUES = frozenset({1, 3})
B5_LOW_VALUE_MAX = 2  # value < 2 -> vertical swing / cool turbo available
B5_FAN_LOW_HIGH_VALUES = frozenset({3, 4, 5, 6, 7, 9})
B5_FAN_MEDIUM_VALUES = frozenset({5, 6, 7})
B5_FAN_AUTO_VALUES = frozenset({4, 5, 6, 9})
B5_FAN_SILENT_VALUES = frozenset({6, 9})
B5_FAN_CUSTOM_VALUE = 1
B5_ECO_VALUES = frozenset({1, 2})
B5_ANION_ON_VALUE = 1
# iECO (0x00E3) capability. The B5 body reports a start byte (index 0) and an
# end byte (index 1); the feature is supported when either names a known iECO
# value. iECO itself is queried/set as a new-protocol on/off feature.
B5_IECO_START_VALUES = frozenset({1, 3, 4, 8})
B5_IECO_END_VALUES = frozenset({1, 2, 3, 8})
# iECO set frame: [0x00 frame, ieco_number, ieco_switch] + this many zero bytes.
IECO_SET_PADDING = 10
B5_TURBO_HEAT_VALUES = frozenset({1, 3})
B5_DISPLAY_VALUES = frozenset({1, 2, 100})
# Temperature capability (0x0225). The value holds per-mode setpoint limits in
# 0.5 C units: six raw bytes are cool then auto then heat, each a min then a
# max, followed by a decimals flag byte.
B5_TEMPERATURE_HALF_DEGREE = 2
B5_TEMPERATURE_COOL_MIN_INDEX = 0
B5_TEMPERATURE_COOL_MAX_INDEX = 1
B5_TEMPERATURE_AUTO_MIN_INDEX = 2
B5_TEMPERATURE_AUTO_MAX_INDEX = 3
B5_TEMPERATURE_HEAT_MIN_INDEX = 4
B5_TEMPERATURE_HEAT_MAX_INDEX = 5
B5_TEMPERATURE_DECIMALS_INDEX_LONG = 6
B5_TEMPERATURE_DECIMALS_INDEX_SHORT = 2
B5_TEMPERATURE_DECIMALS_SIZE_THRESHOLD = 6

# A B5 capability body ends with a trailing [flag, message_id, crc] block. The
# device sets the flag byte non-zero to signal that a second (additional)
# capability frame is available. Unlike msmart-ng (whose payload ends in
# [flag, crc]), midea-lan echoes the message_id byte, so the flag sits three
# bytes from the end of the parsed body.
B5_ADDITIONAL_CAPABILITIES_TRAILER_LENGTH = 3


class PowerFormats(IntEnum):
    """AC Power/Energy analysis formats."""

    # unless stated, consumption / energy is 0.01 kWh, and power in 0.1 W resolution
    BCD = 1
    BINARY = 2  # binary with energy in 0.1 kWh resolution
    MIXED = 3  # mixed/INT (byte = 0-99)
    BINARY1 = 12  # binary
    BCD_ENERGY_BINARY_POWER = 101


class CapabilityTag(IntEnum):
    """New protocol tags in query and response."""

    wind_ud_angle = 0x0009
    wind_lr_angle = 0x000A
    power_on_timer = 0x000B
    power_off_timer = 0x000C
    comfortable_sleep = 0x0011  # comfortableSleepValue
    indoor_humidity = 0x0015  # queryType == "indoor_humidity"
    screen_display = 0x0017
    breezeless = 0x0018  # queryType == "fn_no_wind_sense"
    prompt_tone = 0x001A  # buzzerValue
    voice_control = 0x0020
    cool_hot_sense = 0x0021
    volume_control = 0x0024
    security = 0x0029
    nobody_energy_save = 0x0030
    intelligent_control = 0x0031
    wind_straight = 0x0032
    wind_avoid = 0x0033
    intelligent_wind = 0x0034
    # Live self-clean status. Reported in B0 (set echo) and B1 (query) bodies.
    # The same tag in a B5 capability body only advertises support, not state.
    self_clean = 0x0039
    child_prevent_cold_wind = 0x003A
    error_code = 0x003F
    mode_query = 0x0041
    indirect_wind = 0x0042  # prevent_straight_wind
    gentle_wind_sense = 0x0043
    face_register = 0x0044
    high_temperature_monitor = 0x0047
    rate_select = 0x0048
    prevent_super_cool = 0x0049
    water_washing = 0x004A
    fresh_air_2 = 0x004B  # queryType == "fresh_air"
    extreme_wind = 0x004C
    even_wind = 0x004E
    single_tuyere = 0x004F
    water_pump = 0x0050
    parent_control = 0x0051
    prevent_straight_wind_lr = 0x0058
    wind_around = 0x0059
    degerming = 0x005A
    light = 0x005B
    child_lock = 0x005C
    self_remove_odor_phase = 0x005D
    high_temp_remove_odor_alone = 0x005E
    ozone = 0x005F
    wind_top = 0x0061
    soft_warm = 0x0063
    jet_cool = 0x0067
    rewarming_dry = 0x0068
    arom = 0x0069
    unknown_6d = 0x006D
    control_humidity = 0x007C
    has_cool_heat_amount = 0x0090
    has_icheck = 0x0091
    emergent_heat_wind = 0x0093
    heat_ptc_wind = 0x0094
    unknown_95 = 0x0095
    cvp = 0x0098
    cool_heat = 0x009C
    unknown_9d = 0x009D
    new_wind_sense = 0x00AA
    comfort = 0x00AD
    unknown_c0 = 0x00C0
    meeting_mode = 0x00C1
    one_control = 0x00C2
    # AC outdoor silent mode (PortaSplit)
    out_silent = 0x00CD
    ieco = 0x00E3
    pre_cool_hot = 0x0201
    light_sensitive = 0x0208  # queryType == "light_sensitive"
    pm25_value = 0x020B
    wind_speed = 0x0210
    eco = 0x0212
    b5_8_heat = 0x0213
    # capability tags
    mode = 0x0214
    wind_swing = 0x0215
    electricity = 0x0216
    filter_remind = 0x0217
    ptc = 0x0219
    strong_wind = 0x021A
    little_angel = 0x021B
    anion = 0x021E
    humidity = 0x021F
    filter_check = 0x0221
    fahrenheit = 0x0222
    screen_display_capability = 0x0224
    temperature = 0x0225
    auto_prevent_straight_wind = 0x0226
    remote_control_lock = 0x0227  # power_lock?
    operating_time = 0x0228
    ptc_lock = 0x0229
    offline_operating_time = 0x022B
    sound = 0x022C  # b5_sound / buzzer_all
    twins_machine = 0x0232
    fresh_air_1 = 0x0233
    body_check = 0x0234
    fresh_air_parm = 0x0250
    filter_level = 0x0409


class MessageACBase(MessageRequest):
    """AC message base."""

    _message_serial = 0

    def __init__(
        self,
        protocol_version: int,
        message_type: MessageType,
        body_type: ListTypes,
    ) -> None:
        """Initialize AC message base."""
        super().__init__(
            device_type=DeviceType.AC,
            protocol_version=protocol_version,
            message_type=message_type,
            body_type=body_type,
        )
        MessageACBase._message_serial += 1
        if MessageACBase._message_serial >= MAX_MSG_SERIAL_NUM:
            MessageACBase._message_serial = 1
        self._message_id = MessageACBase._message_serial

    @property
    def _body(self) -> bytearray:
        raise NotImplementedError

    @property
    def body(self) -> bytearray:
        """AC message base body."""
        body = bytearray([self.body_type]) + self._body + bytearray([self._message_id])
        body.append(calculate(body))
        return body


class MessageA0Query(MessageACBase):
    """AC message query(queryType == "a0_query")."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.A0,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        query_body = bytearray(1)
        query_body[0] = 0xA7
        return query_body


class MessageA0LongQuery(MessageACBase):
    """AC message query(queryType == "a0_query_long")."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.A0,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        return bytearray(19)


class StateQuery(MessageACBase):
    """AC message query(queryType == nil)."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        query_body = bytearray(19)
        query_body[0] = 0x81
        query_body[2] = 0xFF
        return query_body


class CapabilitiesQuery(MessageACBase):
    """AC message capabilities query(queryType == "all_first_frame")."""

    def __init__(
        self,
        protocol_version: int,
        additional_capabilities: bool = False,
    ) -> None:
        """Initialize AC message capabilities query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.B5,
        )
        self._additional_capabilities = additional_capabilities

    @property
    def _body(self) -> bytearray:
        if self._additional_capabilities:
            return bytearray([0x01, 0x01, 0x01])
        return bytearray([0x01, 0x00])


class CapabilitiesAdditionalQuery(CapabilitiesQuery):
    """AC message capabilities additional query(queryType == "all_second_frame")."""

    def __init__(
        self,
        protocol_version: int,
    ) -> None:
        """Initialize AC message capabilities additional query."""
        super().__init__(
            protocol_version=protocol_version,
            additional_capabilities=True,  # Always set to True for this class
        )


class GroupDataQuery(MessageACBase):
    """AC message group data query(queryType == "group_data_<group>")."""

    _group = 0

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message group data query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )

    @property
    def _body(self) -> bytearray:
        return bytearray(
            [0x21, 0x01, XC1_GROUP_QUERY_BASE | self._group, 0x00, 0x01],
        )

    @property
    def body(self) -> bytearray:
        """AC message group data query body."""
        body = bytearray([self.body_type]) + self._body
        body.append(calculate(body))
        return body


class GroupZeroQuery(GroupDataQuery):
    """AC message power query(queryType == "group_data_zero")."""

    _group = 0


class GroupOneQuery(GroupDataQuery):
    """AC message compressor query(queryType == "group_data_one")."""

    _group = 1


class GroupTwoQuery(GroupDataQuery):
    """AC message indoor fan query(queryType == "group_data_two")."""

    _group = 2


class PowerQuery(GroupDataQuery):
    """AC message power query(queryType == "group_data_four")."""

    _group = 4


class HumidityQuery(GroupDataQuery):
    """AC message query indoor humidity(queryType == "group_data_five")."""

    _group = 5


class GroupSevenQuery(GroupDataQuery):
    """AC message compressor power query(queryType == "group_data_seven")."""

    _group = 7


class ToggleDisplay(MessageACBase):
    """AC message toggle display."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message toggle display."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )
        self.prompt_tone = False

    @property
    def _body(self) -> bytearray:
        prompt_tone = 0x40 if self.prompt_tone else 0
        return bytearray(
            [
                0x02 | prompt_tone,
                0x00,
                0xFF,
                0x02,
                0x00,
                0x02,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
            ],
        )


# Module-level shared constants for B1 query splitting.
#
# The single CapabilityTag enum above holds every known new-protocol tag. The
# three frozensets below classify those tags into the datasets that drive B1
# querying. Because Python IntEnum cannot inherit members, the categories are
# expressed as frozensets over the one master enum rather than as separate
# enums.

# COMMON_TAGS: tags valid as both a B5 capability and a B1 property. Shared base
# included by both PROPERTIES_TAGS and (by exclusion) CAPABILITY_ONLY_TAGS.
COMMON_TAGS: frozenset[int] = frozenset(
    {
        CapabilityTag.wind_ud_angle,  # 0x0009
        CapabilityTag.wind_lr_angle,  # 0x000A
        CapabilityTag.breezeless,  # 0x0018
        CapabilityTag.self_clean,  # 0x0039
        CapabilityTag.indirect_wind,  # 0x0042
        CapabilityTag.gentle_wind_sense,  # 0x0043
        CapabilityTag.rate_select,  # 0x0048
        CapabilityTag.fresh_air_2,  # 0x004B
        CapabilityTag.wind_around,  # 0x0059
        CapabilityTag.jet_cool,  # 0x0067
        CapabilityTag.out_silent,  # 0x00CD
        CapabilityTag.ieco,  # 0x00E3
        CapabilityTag.anion,  # 0x021E
        CapabilityTag.sound,  # 0x022C
    },
)

# PROPERTIES_TAGS: the B1 allowlist. Only these tags are ever placed in a B1
# query. COMMON_TAGS plus the property-only tags below, all parsed from B1
# bodies and proven on real devices.
PROPERTIES_TAGS: frozenset[int] = COMMON_TAGS | frozenset(
    {
        CapabilityTag.indoor_humidity,  # 0x0015
        CapabilityTag.prompt_tone,  # 0x001A
        CapabilityTag.screen_display,  # 0x0017
        CapabilityTag.error_code,  # 0x003F
        CapabilityTag.fresh_air_1,  # 0x0233
        CapabilityTag.degerming,  # 0x005A
        CapabilityTag.light_sensitive,  # 0x0208
    },
)

# CAPABILITY_ONLY_TAGS: tags that only ever appear in B5 capability
# advertisements, never as valid B1 query tags. Devices reply with an empty
# list when queried with one, suppressing all other tags in the same request.
# COMMON_TAGS are intentionally excluded (they are also valid B1 properties).
CAPABILITY_ONLY_TAGS: frozenset[int] = frozenset(
    {
        CapabilityTag.nobody_energy_save,  # 0x0030
        CapabilityTag.wind_straight,  # 0x0032
        CapabilityTag.wind_avoid,  # 0x0033
        CapabilityTag.prevent_super_cool,  # 0x0049
        CapabilityTag.parent_control,  # 0x0051
        CapabilityTag.prevent_straight_wind_lr,  # 0x0058
        CapabilityTag.temperature,  # 0x0225
        CapabilityTag.twins_machine,  # 0x0232
        CapabilityTag.body_check,  # 0x0234
        CapabilityTag.wind_speed,  # 0x0210
        CapabilityTag.eco,  # 0x0212
        CapabilityTag.b5_8_heat,  # 0x0213
        CapabilityTag.mode,  # 0x0214
        CapabilityTag.wind_swing,  # 0x0215
        CapabilityTag.electricity,  # 0x0216
        CapabilityTag.filter_remind,  # 0x0217
        CapabilityTag.ptc,  # 0x0219
        CapabilityTag.strong_wind,  # 0x021A
        CapabilityTag.humidity,  # 0x021F
        CapabilityTag.filter_check,  # 0x0221
        CapabilityTag.fahrenheit,  # 0x0222
        CapabilityTag.screen_display_capability,  # 0x0224
    },
)

# Default properties queried by PropertiesDefaultQuery (8 properties).
# These are known to be supported by all new-protocol devices and are all
# members of PROPERTIES_TAGS.
_B1_DEFAULT_PROPERTIES: tuple[int, ...] = (
    int(CapabilityTag.indirect_wind),
    int(CapabilityTag.breezeless),
    int(CapabilityTag.indoor_humidity),
    int(CapabilityTag.screen_display),
    int(CapabilityTag.fresh_air_1),
    int(CapabilityTag.fresh_air_2),
    int(CapabilityTag.wind_lr_angle),
    int(CapabilityTag.wind_ud_angle),
)

# Maximum properties per B1 query batch. Verified device boundary on COLMO CA3
# (22019053/22019061, raw B1 frames): <= 9 property IDs per query answer
# normally, >= 10 are suppressed as a whole (only the 0x7e block survives),
# independent of which tags are present. 9 also stays within the 11-property
# bound reported for other families in #1031.
_B1_MAX_PROPERTIES_PER_BATCH = 9

# Number of dynamic capability-property batches (PropertiesCapsQuery + ...1).
# Two batches cover the current collectable capability pool (PROPERTIES_TAGS
# minus the default properties) with headroom for future property tags.
_B1_MAX_CAPABILITY_BATCHES = 2


def format_property_tags(tags: "list[int] | tuple[int, ...]") -> str:
    """Render B1 property tags as a readable "name(0xHHHH)" list for logs.

    Unknown tag values (not in CapabilityTag) fall back to just their hex.
    """
    names: list[str] = []
    for tag in tags:
        try:
            names.append(f"{CapabilityTag(tag).name}(0x{tag:04X})")
        except ValueError:
            names.append(f"0x{tag:04X}")
    return ", ".join(names)


class PropertiesDefaultQuery(MessageACBase):
    """AC new-protocol query for default properties only.

    Queries the 8 fixed default properties that all new-protocol devices
    support. This query is always sent and never includes capability-based
    properties, ensuring it cannot fail due to unsupported tags.
    """

    def __init__(self, protocol_version: int) -> None:
        """Initialize default properties query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.B1,
        )
        self.properties: tuple[int, ...] = _B1_DEFAULT_PROPERTIES

    @property
    def _body(self) -> bytearray:
        params = self.properties
        _body = bytearray([len(params)])
        for param in params:
            _body.extend([param & 0xFF, param >> 8])
        return _body


class _PropertiesCapsQueryBase(MessageACBase):
    """Base class for capability-based properties queries.

    Subclasses (PropertiesCapsQuery, PropertiesCapsQuery1) query capability-based
    properties in separate batches to prevent an unsupported property from
    suppressing default properties.
    """

    def __init__(
        self,
        protocol_version: int,
        *,
        properties_subset: list[int],
    ) -> None:
        """Initialize capability properties query.

        Args:
            protocol_version: Protocol version.
            properties_subset: List of capability property tags (as integers)
                to include in this query batch.

        """
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.B1,
        )
        self.properties: tuple[int, ...] = tuple(sorted(properties_subset))

    @property
    def _body(self) -> bytearray:
        params = self.properties
        _body = bytearray([len(params)])
        for param in params:
            _body.extend([param & 0xFF, param >> 8])
        return _body

    @staticmethod
    def collect_capability_properties(
        capabilities: dict[str, CapabilityValue],
    ) -> list[int]:
        """Collect capability properties from capabilities dict.

        Returns a sorted list of capability property tag integers that should
        be queried based on the device's advertised capabilities.

        Uses an allowlist model: a tag is collected only if it is a member of
        PROPERTIES_TAGS (the B1-queryable allowlist) and is not already in
        _B1_DEFAULT_PROPERTIES (queried by PropertiesDefaultQuery). Any tag not
        in PROPERTIES_TAGS (capability-only or unknown) is never queried in B1.

        Args:
            capabilities: Device capabilities dict from B5 + customize.

        Returns:
            Sorted list of capability property tags to query.

        """
        properties: list[int] = []
        default_tags = frozenset(_B1_DEFAULT_PROPERTIES)

        for key, value in capabilities.items():
            if not value:
                continue  # Skip falsy values
            try:
                tag = int(CapabilityTag[key])
            except KeyError:
                continue  # Not a valid tag name
            if tag not in PROPERTIES_TAGS:
                continue  # Not a B1-queryable property (capability-only)
            if tag in default_tags:
                continue  # Already in default query
            properties.append(tag)

        return sorted(properties)


class PropertiesCapsQuery(_PropertiesCapsQueryBase):
    """First dynamic capability properties query batch."""


class PropertiesCapsQuery1(_PropertiesCapsQueryBase):
    """Second dynamic capability properties query batch."""


class MessageSubProtocol(MessageACBase):
    """AC message sub protocol."""

    def __init__(
        self,
        protocol_version: int,
        message_type: MessageType,
        subprotocol_query_type: int,
    ) -> None:
        """Initialize AC message sub protocol."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=message_type,
            body_type=ListTypes.AA,
        )
        self._subprotocol_query_type = subprotocol_query_type

    @property
    def _subprotocol_body(self) -> bytes | bytearray:
        return bytes([])

    @property
    def body(self) -> bytearray:
        """AC message sub protocol body."""
        body = bytearray([self.body_type]) + self._body
        body.append(calculate(body))
        body.append(self.checksum(body))
        return body

    @property
    def _body(self) -> bytearray:
        _subprotocol_body = self._subprotocol_body
        _body = bytearray(
            [
                6 + 2 + len(_subprotocol_body),
                0x00,
                0xFF,
                0xFF,
                self._subprotocol_query_type,
            ],
        )
        _body.extend(_subprotocol_body)
        return _body


class SubProtocolQuery(MessageSubProtocol):
    """AC message sub protocol query."""

    def __init__(
        self,
        protocol_version: int,
        subprotocol_query_type: int,
    ) -> None:
        """Initialize AC message sub protocol query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            subprotocol_query_type=subprotocol_query_type,
        )


class SubProtocolQuery10(SubProtocolQuery):
    """AC sub protocol indoor status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the indoor status query."""
        super().__init__(protocol_version, ListTypes.X10)


class SubProtocolQuery11(SubProtocolQuery):
    """AC sub protocol basic status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the basic status query."""
        super().__init__(protocol_version, ListTypes.X11)


class SubProtocolQuery30(SubProtocolQuery):
    """AC sub protocol outdoor status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the outdoor status query."""
        super().__init__(protocol_version, ListTypes.X30)


class MessageSubProtocolSet(MessageSubProtocol):
    """AC message sub protocol set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message sub protocol set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            subprotocol_query_type=0x20,
        )
        self.power = False
        self.mode = 0
        self.target_temperature = 20.0
        self.fan_speed = 102
        self.boost_mode = False
        self.aux_heating = False
        self.dry = False
        self.eco_mode = False
        self.sleep_mode = False
        self.sn8_flag = False
        self.timer = False
        self.prompt_tone = False

    @property
    def _subprotocol_body(self) -> bytearray:
        power = 0x01 if self.power else 0
        dry = 0x10 if self.power and self.dry else 0
        boost_mode = 0x20 if self.boost_mode else 0
        aux_heating = 0x40 if self.aux_heating else 0x80
        sleep_mode = 0x80 if self.sleep_mode else 0
        try:
            mode = 0 if self.mode == 0 else BB_AC_MODES[self.mode] - 1
        except IndexError:
            mode = 2  # set Auto if invalid mode
        target_temperature = int(self.target_temperature * 2 + 30)
        water_model_temperature_set = int((self.target_temperature - 1) * 2 + 50)
        fan_speed = int(self.fan_speed)
        eco = 0x40 if self.eco_mode else 0

        prompt_tone = 0x01 if self.prompt_tone else 0
        timer = 0x04 if (self.sn8_flag and self.timer) else 0
        return bytearray(
            [
                0x02 | boost_mode | power | dry,
                aux_heating,
                sleep_mode,
                0x00,
                0x00,
                mode,
                target_temperature,
                fan_speed,
                0x32,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x01,
                0x01,
                0x00,
                0x01,
                water_model_temperature_set,
                prompt_tone,
                target_temperature,
                0x32,
                0x66,
                0x00,
                eco | timer,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x08,
            ],
        )


class SubProtocolFreshAirSet(MessageSubProtocol):
    """AC BB C0/02 single-control fresh-air command."""

    def __init__(
        self,
        protocol_version: int,
        power: bool,
        speed: int,
        *,
        exhaust: bool = False,
    ) -> None:
        """Initialize a fresh-air intake or exhaust command."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            subprotocol_query_type=ListTypes.C0,
        )
        self.power = power
        self.speed = max(1, min(speed, 100))
        self.exhaust = exhaust

    @property
    def _subprotocol_body(self) -> bytearray:
        body = bytearray(BB_FRESH_AIR_CONTROL_BODY_LENGTH)
        # BB fresh-air controls are sparse C0/02 payloads. The switch bytes are
        # relative to the control cursor; speed bytes are offsets in that block.
        body[1] = 0x01
        body[2] = 0x01
        body[11] = 0x01
        body[12] = ListTypes.C0
        body[13] = 0x02
        body[14] = 0x54
        switch_mask = (
            BB_FRESH_AIR_EXHAUST_SWITCH_MASK
            if self.exhaust
            else BB_FRESH_AIR_INTAKE_SWITCH_MASK
        )
        speed_index = (
            BB_FRESH_AIR_EXHAUST_CONTROL_SPEED_INDEX
            if self.exhaust
            else BB_FRESH_AIR_INTAKE_CONTROL_SPEED_INDEX
        )
        body[BB_FRESH_AIR_CONTROL_CURSOR + 6] = switch_mask
        body[BB_FRESH_AIR_CONTROL_CURSOR + 7] = switch_mask if self.power else 0
        body[BB_FRESH_AIR_CONTROL_CURSOR + speed_index] = (
            BB_FRESH_AIR_SPEED_FLAG | self.speed
        )
        body[-1] = (-sum(body[12:-1])) & MAX_BYTE_VALUE
        return body


class StateSet(MessageACBase):
    """AC message general set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message general set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            body_type=ListTypes.X40,
        )
        self.power = False
        self.prompt_tone = True
        self.mode = 0
        self.target_temperature = 20.0
        self.fan_speed = 102
        self.swing_vertical = False
        self.swing_horizontal = False
        self.boost_mode = False
        self.power_saving = False
        self.smart_eye = False
        self.dry = False
        self.aux_heating = False
        self.eco_mode = False
        self.temp_fahrenheit = False
        self.sleep_mode = False
        self.natural_wind = False
        self.frost_protect = False
        self.comfort_mode = False
        self.anion = False
        # Countdown timers in minutes (0 = disarm). When both stay None the
        # timer bytes are sent as 00 00 00, which clears any armed timer.
        # Unlike the vendor app, which always sends the timer flag, this keeps
        # the bytes of devices that never use timers unchanged.
        self.power_on_timer: int | None = None
        self.power_off_timer: int | None = None

    def _timer_bytes(self) -> tuple[int, int, int, int]:
        """Return (fan flag, power-on slot, power-off slot, minute nibbles)."""
        if self.power_on_timer is None and self.power_off_timer is None:
            return 0x00, 0x00, 0x00, 0x00
        on_slot, on_correction = encode_countdown_timer(self.power_on_timer or 0)
        off_slot, off_correction = encode_countdown_timer(self.power_off_timer or 0)
        return (
            COUNTDOWN_TIMER_SET_FLAG,
            on_slot,
            off_slot,
            (on_correction << NEW_PROTOCOL_TIMER_POWER_ON_CORRECTION_SHIFT)
            | off_correction,
        )

    @property
    def _body(self) -> bytearray:
        # Byte1, Power, prompt_tone
        power = 0x01 if self.power else 0
        prompt_tone = 0x40 if self.prompt_tone else 0
        # Byte2, mode target_temperature
        mode = (self.mode << 5) & 0xE0
        target_temperature = (int(self.target_temperature) & 0xF) | (
            0x10 if round(self.target_temperature * 2) % 2 != 0 else 0
        )
        # Byte 3, fan_speed
        fan_speed = int(self.fan_speed) & 0x7F
        # Byte 7, swing_mode
        swing_mode = (
            0x30
            | (0x0C if self.swing_vertical else 0)
            | (0x03 if self.swing_horizontal else 0)
        )
        # Byte 8, turbo, power saving
        boost_mode = 0x20 if self.boost_mode else 0
        power_saving = POWER_SAVING_VALUE if self.power_saving else 0
        # Byte 9 aux_heating eco_mode
        smart_eye = 0x01 if self.smart_eye else 0
        dry = 0x04 if self.dry else 0
        aux_heating = 0x08 if self.aux_heating else 0
        eco_mode = 0x80 if self.eco_mode else 0
        anion = 0x20 if self.anion else 0
        # Byte 10 temp_fahrenheit
        temp_fahrenheit = 0x04 if self.temp_fahrenheit else 0
        sleep_mode = 0x01 if self.sleep_mode else 0
        boost_mode_1 = 0x02 if self.boost_mode else 0
        # Byte 17 natural_wind
        natural_wind = 0x40 if self.natural_wind else 0
        # Lua bodyBytes[18] extends the normal target field below 17 C.
        low_target_temperature = (
            (int(self.target_temperature) - LOW_TARGET_TEMPERATURE_OFFSET)
            & LOW_TARGET_TEMPERATURE_MASK
            if self.target_temperature < LOW_TARGET_TEMPERATURE_BOUNDARY
            else 0
        )
        # Byte 21 frost_protect
        frost_protect = 0x80 if self.frost_protect else 0
        # Byte 22 comfort_mode
        comfort_mode = 0x01 if self.comfort_mode else 0
        # Byte 3 timer flag, bytes 4-6 countdown timers
        timer_flag, power_on_timer, power_off_timer, timer_minutes = self._timer_bytes()

        return bytearray(
            [
                power | prompt_tone,
                mode | target_temperature,
                fan_speed | timer_flag,
                power_on_timer,
                power_off_timer,
                timer_minutes,
                swing_mode,
                boost_mode | power_saving,
                smart_eye | dry | aux_heating | eco_mode | anion,
                temp_fahrenheit | sleep_mode | boost_mode_1,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                natural_wind,
                low_target_temperature,
                0x00,
                0x00,
                frost_protect,
                comfort_mode,
            ],
        )


class PropertiesSet(MessageACBase):
    """AC message new protocol set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message new protocol set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            body_type=ListTypes.B0,
        )
        self.indirect_wind: bytes | None = None
        self.prompt_tone: bytes | None = None
        self.breezeless: bytes | None = None
        self.screen_display_alternate: bytes | None = None
        self.fresh_air_1: bytes | None = None
        self.fresh_air_2: bytes | None = None
        self.wind_lr_angle: bytes | None = None
        self.wind_ud_angle: bytes | None = None
        self.rate_select: int | None = None
        self.out_silent: bool | None = None
        self.out_silent_on_value: int = DEFAULT_OUT_SILENT_VALUE
        self.sound: bool | None = None
        self.self_clean: bool | None = None
        self.degerming: bool | None = None
        self.light_sensitive: bool | None = None
        self.ieco: bool | None = None
        self.ieco_number: int = 1
        # Countdown timers in minutes (0 = disarm).
        self.power_on_timer: int | None = None
        self.power_off_timer: int | None = None

    @property
    def _body(self) -> bytearray:
        pack_count = 0
        payload = bytearray([0x00])
        if self.breezeless is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.breezeless,
                    value=bytearray([0x01 if self.breezeless else 0x00]),
                ),
            )
        if self.indirect_wind is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.indirect_wind,
                    value=bytearray([0x02 if self.indirect_wind else 0x01]),
                ),
            )
        if self.prompt_tone is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.prompt_tone,
                    value=bytearray([0x01 if self.prompt_tone else 0x00]),
                ),
            )
        if self.screen_display_alternate is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.screen_display,
                    value=bytearray([0x64 if self.screen_display_alternate else 0x00]),
                ),
            )
        if self.fresh_air_1 is not None and len(self.fresh_air_1) == FRESH_AIR_LENGTH:
            pack_count += 1
            fresh_air_power = 2 if next(iter(self.fresh_air_1)) > 0 else 1
            fresh_air_fan_speed = list(self.fresh_air_1)[1]
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.fresh_air_1,
                    value=bytearray(
                        [
                            fresh_air_power,
                            fresh_air_fan_speed,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                        ],
                    ),
                ),
            )
        if self.fresh_air_2 is not None and len(self.fresh_air_2) == FRESH_AIR_LENGTH:
            pack_count += 1
            fresh_air_power = 1 if next(iter(self.fresh_air_2)) > 0 else 0
            fresh_air_fan_speed = list(self.fresh_air_2)[1]
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.fresh_air_2,
                    value=bytearray([fresh_air_power, fresh_air_fan_speed, 0xFF]),
                ),
            )
        if self.wind_lr_angle is not None:
            pack_count += 1
            wind_lr_angle = int(self.wind_lr_angle)
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.wind_lr_angle,
                    value=bytearray([wind_lr_angle if wind_lr_angle else 0x00]),
                ),
            )
        if self.wind_ud_angle is not None:
            pack_count += 1
            wind_ud_angle = int(self.wind_ud_angle)
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.wind_ud_angle,
                    value=bytearray([wind_ud_angle if wind_ud_angle else 0x00]),
                ),
            )
        if self.out_silent is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.out_silent,
                    value=bytearray(
                        [
                            self.out_silent_on_value
                            if self.out_silent
                            else OUT_SILENT_OFF_VALUE,
                        ],
                    ),
                ),
            )
        if self.sound is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.sound,
                    value=bytearray([0x01 if self.sound else 0x00]),
                ),
            )
        if self.self_clean is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.self_clean,
                    value=bytearray([0x01 if self.self_clean else 0x00]),
                ),
            )
        if self.degerming is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.degerming,
                    value=bytearray([0x01 if self.degerming else 0x00]),
                ),
            )
        if self.light_sensitive is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.light_sensitive,
                    # The payload carries a 2-bit level; the vendor app only
                    # uses 0x00 (off) and 0x03 (on) - verified with LAN set
                    # frames on both models.
                    value=bytearray([0x03 if self.light_sensitive else 0x00]),
                ),
            )
        if self.rate_select is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.rate_select,
                    value=bytearray([int(self.rate_select)]),
                ),
            )
        if self.ieco is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.ieco,
                    # [frame, ieco_number, switch] followed by zero padding.
                    value=bytearray(
                        [0x00, self.ieco_number, 0x01 if self.ieco else 0x00],
                    )
                    + bytearray(IECO_SET_PADDING),
                ),
            )
        if self.power_on_timer is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.power_on_timer,
                    value=encode_properties_timer(self.power_on_timer),
                ),
            )
        if self.power_off_timer is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=CapabilityTag.power_off_timer,
                    value=encode_properties_timer(self.power_off_timer),
                ),
            )
        payload[0] = pack_count
        return payload


class XA0Body(MessageBody):
    """AC A0 message body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC A0 message body."""
        super().__init__(body)
        self.power = (body[1] & 0x1) > 0  # powerValue
        # temperature & smallTemperature
        self.target_temperature = (
            ((body[1] & 0x3E) >> 1) - 4 + 16.0 + (0.5 if body[1] & 0x40 > 0 else 0.0)
        )
        self.mode = (body[2] & 0xE0) >> 5  # modeValue
        self.fan_speed = body[3] & 0x7F  # fanspeedValue
        self.swing_vertical = (body[7] & 0xC) > 0  # swingLRValue
        self.swing_horizontal = (body[7] & 0x3) > 0  # swingUDValue
        # strongWindValue
        self.boost_mode = ((body[8] & 0x20) > 0) or ((body[10] & 0x2) > 0)
        self.power_saving = (body[8] & POWER_SAVING_VALUE) > 0
        self.comfort_sleep = body[8] & 0x03  # comfortableSleepValue
        self.comfort_sleep_switch = body[14] & 0x01  # comfortableSleepSwitch
        self.pmv = ((body[11] & 0xF0) >> 4) * 0.5 - 3.5  # pmv
        # screenDisplayNowValue
        self.screen_display = (
            (body[14] >> 4 & 0x7) != SCREEN_DISPLAY_BYTE_CHECK
        ) and self.power
        self.smart_eye = (body[9] & 0x01) > 0
        self.dry = (body[9] & 0x04) > 0  # dryValue
        self.aux_heating = (body[9] & 0x08) > 0  # PTCValue
        self.purifier = body[9] & 0x20  # purifierValue
        self.anion = (body[9] & 0x20) > 0
        self.eco_mode = (body[9] & 0x10) > 0  # ecoValue
        self.sleep_mode = (body[10] & 0x01) > 0
        self.natural_wind = (body[10] & 0x40) > 0  # naturalWind
        self.smart_dry = body[13] & 0x7F  # smartDryValue
        self.kick_quilt = (body[10] & 0x04) >> 2  # kickQuilt
        self.prevent_cold = (body[10] & 0x08) >> 3  # preventCold
        self.full_dust = ((body[13] & 0x20) >> 5) > 0  # dust_full_time
        # comfortPowerSave
        self.comfort_mode = (body[14] & 0x1) > 0
        # smartDryValue
        self.smart_dry = (body[13] & 0x7F) > 0
        # swingLRUnderSwitch
        self.swing_lr_switch = (
            body[19] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        )
        # swingLRValueUnder
        self.swing_lr_value = body[9] & 0x40
        # arom
        self.frost_protect = (
            ((body[21] & 0x80) >> 7) > 0
            if len(body) >= FROST_PROTECT_MIN_LENGTH
            else False
        )
        if len(body) >= FRESH_AIR_C0_MIN_LENGTH:
            self.fresh_filter_time_total = body[25] * 256 + body[24]
            self.fresh_filter_time_use = body[16] * 256 + body[15]
            self.fresh_filter_timeout = (body[13] & 0x40) >> 6


class XMessageBody(MessageBody):
    """AC A1/C0 message body - common functions."""

    @staticmethod
    def parse_temperature(integer: int, decimal: int) -> float | None:
        """Decode special signed integer with BCD decimal temperature format."""
        if integer == MAX_BYTE_VALUE:
            return None
        temp_integer = (integer - 50) / 2
        if decimal == 0:
            return temp_integer
        if temp_integer < 0:
            return int(temp_integer) - decimal * 0.1
        return int(temp_integer) + decimal * 0.1


class XA1Body(XMessageBody):
    """AC A1 message body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC A1 message body."""
        super().__init__(body)
        # currentWorkTime
        self.current_work_time = (
            (((body[9] << 8) & 0xFF00) | (body[10] & 0x00FF)) * 60 * 24
            + body[11] * 60
            + body[12]
        )
        decimal = body[18] if len(body) > TEMP_DECIMAL_MIN_BODY_LENGTH else 0
        self.indoor_temperature = self.parse_temperature(body[13], decimal & 0x0F)
        self.outdoor_temperature = self.parse_temperature(body[14], decimal >> 4)
        self.indoor_humidity = body[17] if body[17] != 0 else None


def parse_countdown_timer(value: int, minute_correction: int) -> int:
    """Decode an armed countdown timer slot into minutes (0 = not armed)."""
    if not (value & NEW_PROTOCOL_TIMER_ARMED_MASK):
        return 0
    hours = (value & NEW_PROTOCOL_TIMER_VALUE_MASK) >> NEW_PROTOCOL_TIMER_HOUR_SHIFT
    quarter_hours = value & NEW_PROTOCOL_TIMER_QUARTER_MASK
    return (
        hours * NEW_PROTOCOL_TIMER_MINUTES_PER_HOUR
        + quarter_hours * NEW_PROTOCOL_TIMER_MINUTES_PER_QUARTER
        + NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MAX
        - minute_correction
    )


def encode_countdown_timer(minutes: int) -> tuple[int, int]:
    """Encode minutes into (slot byte, minute correction nibble); 0 = disarm.

    Inverse of parse_countdown_timer. The slot byte holds the armed flag,
    hours and quarter-hours; the nibble holds 15 minus the minutes past the
    last quarter-hour.
    """
    if minutes <= 0:
        return COUNTDOWN_TIMER_SLOT_DISARMED, NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MAX
    if minutes > COUNTDOWN_TIMER_MAX_MINUTES:
        _LOGGER.debug(
            "Countdown timer %d min clamped to %d min",
            minutes,
            COUNTDOWN_TIMER_MAX_MINUTES,
        )
        minutes = COUNTDOWN_TIMER_MAX_MINUTES
    hours, rest = divmod(minutes, NEW_PROTOCOL_TIMER_MINUTES_PER_HOUR)
    quarter_hours, extra = divmod(rest, NEW_PROTOCOL_TIMER_MINUTES_PER_QUARTER)
    return (
        NEW_PROTOCOL_TIMER_ARMED_MASK
        | (hours << NEW_PROTOCOL_TIMER_HOUR_SHIFT)
        | quarter_hours,
        NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MAX - extra,
    )


def encode_properties_timer(minutes: int) -> bytearray:
    """Encode minutes into the B0 [switch, hours, minutes] value; 0 = disarm."""
    if minutes <= 0:
        return bytearray([PROPERTIES_TIMER_SWITCH_OFF, 0x00, 0x00])
    hours, rest = divmod(minutes, NEW_PROTOCOL_TIMER_MINUTES_PER_HOUR)
    if hours > MAX_BYTE_VALUE:
        _LOGGER.debug("Countdown timer %d min clamped to 255 h", minutes)
        hours, rest = MAX_BYTE_VALUE, 0
    return bytearray([PROPERTIES_TIMER_SWITCH_ON, hours, rest])


class PropertiesBody(NewProtocolMessageBody):
    """AC Bx message body. body[0] b0/b1, body[1] propertyNumber, cursor 2."""

    def _parse_queried_states(self, params: dict[int, bytearray]) -> None:
        """Parse live states from queried property tags (B0/B1 bodies only).

        A B5 body carries these tags as capability flags rather than live
        state, so it is filtered out here; the 0x7e payload carries the same
        states for every body type (parsed in __init__ below).
        """
        if CapabilityTag.degerming in params and self.body_type != ListTypes.B5:
            # Queried degerming state (0x00 off / 0x01 on).
            self.degerming_active = params[CapabilityTag.degerming][0] > 0
        if CapabilityTag.light_sensitive in params and self.body_type != ListTypes.B5:
            # Queried light sensitivity level (0 = off, 1-3 = on, matching the
            # 0x7e payload byte).
            self.light_sensitive_active = params[CapabilityTag.light_sensitive][0] > 0

    def __init__(
        self,
        body: bytearray,
        new_protocol_temperature: bool = False,
    ) -> None:
        """Initialize AC BX message body."""
        super().__init__(body)

        params = self.parse()
        if CapabilityTag.indirect_wind in params:
            self.indirect_wind = (
                params[CapabilityTag.indirect_wind][0] == INDIRECT_WIND_VALUE
            )
        if CapabilityTag.indoor_humidity in params:
            indoor_humidity = params[CapabilityTag.indoor_humidity][0]
            self.indoor_humidity = indoor_humidity if indoor_humidity != 0 else None
        if CapabilityTag.breezeless in params:
            self.breezeless = params[CapabilityTag.breezeless][0] == 1
        if CapabilityTag.screen_display in params:
            self.screen_display_alternate = params[CapabilityTag.screen_display][0] > 0
            self.screen_display_new = True
        if CapabilityTag.fresh_air_1 in params:
            self.fresh_air_1 = True
            data = params[CapabilityTag.fresh_air_1]
            self.fresh_air_power = data[0] == INDIRECT_WIND_VALUE
            self.fresh_air_fan_speed = data[1]
        if CapabilityTag.fresh_air_2 in params:
            self.fresh_air_2 = True
            data = params[CapabilityTag.fresh_air_2]
            self.fresh_air_power = data[0] > 0
            self.fresh_air_fan_speed = data[1]
        if CapabilityTag.wind_lr_angle in params:
            self.wind_lr_angle = params[CapabilityTag.wind_lr_angle][0]
        if CapabilityTag.wind_ud_angle in params:
            self.wind_ud_angle = params[CapabilityTag.wind_ud_angle][0]
        if CapabilityTag.rate_select in params:
            self.rate_select = params[CapabilityTag.rate_select][0]
        if CapabilityTag.out_silent in params:
            self.out_silent = params[CapabilityTag.out_silent][0] > 0
        if CapabilityTag.sound in params:
            self.sound = params[CapabilityTag.sound][0] > 0
        if CapabilityTag.error_code in params:
            self.error_code = params[CapabilityTag.error_code][0]
        if CapabilityTag.self_clean in params and self.body_type != ListTypes.B5:
            # A B5 body carries this tag as a capability flag (always 1 when the
            # model supports self-clean), so only B0/B1 bodies report live state.
            self.self_clean_active: bool = params[CapabilityTag.self_clean][0] > 0
        self._parse_queried_states(params)
        if (
            NEW_PROTOCOL_TEMPERATURE_TAG in params
            and len(params[NEW_PROTOCOL_TEMPERATURE_TAG]) > NEW_PROTOCOL_DEGERMING_BYTE
        ):
            # Live degerming (sterilize) state. A B5 notify body carries the
            # live value as well (verified with state toggles),
            # so no body-type filter is applied here. The notify payload's raw
            # head differs from B0/B1, but this slice keeps index 19 valid.
            self.degerming_active = (
                params[NEW_PROTOCOL_TEMPERATURE_TAG][NEW_PROTOCOL_DEGERMING_BYTE]
                & NEW_PROTOCOL_DEGERMING_MASK
            ) > 0
        if (
            NEW_PROTOCOL_TEMPERATURE_TAG in params
            and len(params[NEW_PROTOCOL_TEMPERATURE_TAG])
            > NEW_PROTOCOL_LIGHT_SENSITIVE_BYTE
        ):
            # Light sensitivity, the two countdown timer slots and the live
            # self-clean state share the 0x7e payload with the state bytes
            # above and, like degerming, are reported in B0/B1 bodies as
            # well as B5 notify bodies.
            new_protocol_data = params[NEW_PROTOCOL_TEMPERATURE_TAG]
            self.light_sensitive_active = (
                new_protocol_data[NEW_PROTOCOL_LIGHT_SENSITIVE_BYTE]
                & NEW_PROTOCOL_LIGHT_SENSITIVE_MASK
            ) > 0
            self.power_on_timer: int = parse_countdown_timer(
                new_protocol_data[NEW_PROTOCOL_POWER_ON_TIMER_BYTE],
                (
                    new_protocol_data[NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_BYTE]
                    >> NEW_PROTOCOL_TIMER_POWER_ON_CORRECTION_SHIFT
                ),
            )
            self.power_off_timer: int = parse_countdown_timer(
                new_protocol_data[NEW_PROTOCOL_POWER_OFF_TIMER_BYTE],
                new_protocol_data[NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_BYTE]
                & NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MASK,
            )
            # The live self-clean state is carried by this payload too. The
            # property tag above only advertises the capability in B5
            # bodies, so this byte is what updates B5 notifies as well;
            # both sources agree within a frame (verified against app
            # driven start/cancel captures).
            self.self_clean_active = (
                new_protocol_data[NEW_PROTOCOL_SELF_CLEAN_BYTE]
                & NEW_PROTOCOL_SELF_CLEAN_MASK
            ) > 0
        # Tag presence and the 22013279 gate are handled inside the helper;
        # the call stays unconditional to keep this method within the
        # complexity budget.
        self._parse_new_protocol_extensions(params, new_protocol_temperature)
        if (
            CapabilityTag.ieco in params
            and self.body_type != ListTypes.B5
            and len(params[CapabilityTag.ieco]) > 1
        ):
            # data[0] - iECO number (current gear), data[1] - on/off switch.
            # Only B0/B1 bodies report live state; a B5 body carries this tag as
            # a capability advertisement instead.
            ieco_data = params[CapabilityTag.ieco]
            self.ieco = ieco_data[1] > 0
            self.ieco_number = ieco_data[0]
        if (
            new_protocol_temperature
            and NEW_PROTOCOL_TEMPERATURE_TAG in params
            and self._parse_new_protocol_temperatures(
                params[NEW_PROTOCOL_TEMPERATURE_TAG],
            )
        ):
            self.has_new_protocol_temperature = True

    def _parse_new_protocol_extensions(
        self,
        params: dict[int, bytearray],
        new_protocol_temperature: bool,
    ) -> None:
        """Read live state and generic-branch temperatures from the 0x7e payload.

        Live power, mode, fan speed, indirect wind, indoor humidity, swing
        flags and fixed louver angles ride the same 0x7e payload (same
        encoding as the C0/A0 state bodies; swing/angle encoding verified
        against the vendor Lua and HA state history on model 22019061,
        2026-10-08). The generic temperature branch (bytes 1, 40, 41; same
        encodings as XA0Body) is dual-path: it does not set
        has_new_protocol_temperature, so the C0/A0/A1 sources keep updating
        and are never suppressed. This is skipped entirely for the 22013279
        new-protocol-temperature path, where byte-1 encoding is known to
        differ.
        """
        if new_protocol_temperature or NEW_PROTOCOL_TEMPERATURE_TAG not in params:
            return
        data = params[NEW_PROTOCOL_TEMPERATURE_TAG]
        if len(data) > NEW_PROTOCOL_WIND_ANGLE_BYTE:
            self.swing_vertical = (
                data[NEW_PROTOCOL_SWING_BYTE] & NEW_PROTOCOL_SWING_VERTICAL_MASK
            ) > 0
            self.swing_horizontal = (
                data[NEW_PROTOCOL_SWING_BYTE] & NEW_PROTOCOL_SWING_HORIZONTAL_MASK
            ) > 0
            lr_grade = NEW_PROTOCOL_WIND_ANGLE_GRADES.get(
                data[NEW_PROTOCOL_WIND_ANGLE_BYTE] >> NEW_PROTOCOL_WIND_LR_ANGLE_SHIFT,
            )
            if lr_grade in NEW_PROTOCOL_WIND_ANGLE_LIB_GRADES:
                self.wind_lr_angle = lr_grade
            ud_grade = NEW_PROTOCOL_WIND_ANGLE_GRADES.get(
                data[NEW_PROTOCOL_WIND_ANGLE_BYTE] & NEW_PROTOCOL_WIND_UD_ANGLE_MASK,
            )
            if ud_grade in NEW_PROTOCOL_WIND_ANGLE_LIB_GRADES:
                self.wind_ud_angle = ud_grade
        if len(data) > NEW_PROTOCOL_INDOOR_HUMIDITY_BYTE:
            self.power = (data[NEW_PROTOCOL_POWER_BYTE] & NEW_PROTOCOL_POWER_MASK) > 0
            self.mode = (
                data[NEW_PROTOCOL_MODE_BYTE] & NEW_PROTOCOL_MODE_MASK
            ) >> NEW_PROTOCOL_MODE_SHIFT
            self.fan_speed = (
                data[NEW_PROTOCOL_FAN_SPEED_BYTE] & NEW_PROTOCOL_FAN_SPEED_MASK
            )
            self.indirect_wind = (
                data[NEW_PROTOCOL_INDIRECT_WIND_BYTE] & NEW_PROTOCOL_INDIRECT_WIND_MASK
            ) > 0
            indoor_humidity = data[NEW_PROTOCOL_INDOOR_HUMIDITY_BYTE]
            if indoor_humidity == 0:
                # Library convention: 0 = no reading reported. Preserve any
                # reading the capability tag already provided in this frame.
                if not hasattr(self, "indoor_humidity"):
                    self.indoor_humidity = None
            elif indoor_humidity <= NEW_PROTOCOL_INDOOR_HUMIDITY_MAX:
                self.indoor_humidity = indoor_humidity
            # Values above the bound are implausible: skip, keep the last value.
        if len(data) > NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE:
            raw_setpoint = data[NEW_PROTOCOL_POWER_BYTE]
            target_temperature = (
                (
                    (raw_setpoint & NEW_PROTOCOL_GENERIC_SETPOINT_MASK)
                    >> NEW_PROTOCOL_GENERIC_SETPOINT_SHIFT
                )
                + NEW_PROTOCOL_GENERIC_SETPOINT_OFFSET
                + (
                    NEW_PROTOCOL_GENERIC_SETPOINT_HALF_DEGREE_STEP
                    if raw_setpoint & NEW_PROTOCOL_GENERIC_SETPOINT_HALF_DEGREE_BIT
                    else 0.0
                )
            )
            indoor_temperature = XMessageBody.parse_temperature(
                data[NEW_PROTOCOL_INDOOR_TEMPERATURE_BYTE],
                data[NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE]
                & NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_MASK,
            )
            if (
                NEW_PROTOCOL_MIN_VALID_TEMPERATURE
                <= target_temperature
                <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
            ):
                self.target_temperature = target_temperature
            if (
                indoor_temperature is not None
                and NEW_PROTOCOL_MIN_VALID_TEMPERATURE
                <= indoor_temperature
                <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
            ):
                self.indoor_temperature = indoor_temperature

    def _parse_new_protocol_temperatures(self, data: bytearray) -> bool:
        """Decode setpoint and indoor temperature for model 22013279.

        Its standard C0 temperature fields are stale; temperatures are reported
        in this new-protocol tag instead. Synced captures show the setpoint in
        byte 1:
        - low 6 bits encode 0.5C steps with a +11.5C offset
        - bit 0x40 adds an extra +0.5C

        Only call this for model 22013279. For other models, this tag is not
        known to supersede C0; accepting it would latch B1 values and discard
        C0 temperatures, including any outdoor reading.
        """
        if len(data) <= NEW_PROTOCOL_TEMPERATURE_MIN_LENGTH:
            return False
        raw_setpoint = data[1]
        target_temperature = (
            NEW_PROTOCOL_SETPOINT_OFFSET
            + (raw_setpoint & NEW_PROTOCOL_SETPOINT_MASK) / 2
        )
        if raw_setpoint & NEW_PROTOCOL_SETPOINT_HALF_DEGREE_BIT:
            target_temperature += 0.5
        if not (
            NEW_PROTOCOL_MIN_VALID_TEMPERATURE
            <= target_temperature
            <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
        ):
            # Fallback for payload variants where the legacy byte-3 mapping
            # is still active.
            fallback_target = (data[NEW_PROTOCOL_LEGACY_SETPOINT_BYTE] - 50) / 2
            if (
                NEW_PROTOCOL_MIN_VALID_TEMPERATURE
                <= fallback_target
                <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
            ):
                target_temperature = fallback_target
            else:
                return False
        indoor_temperature = round(
            (data[NEW_PROTOCOL_INDOOR_TEMPERATURE_BYTE] - 50) / 2
            + data[NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE] * 0.1,
            1,
        )
        if not (
            NEW_PROTOCOL_MIN_VALID_TEMPERATURE
            <= indoor_temperature
            <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
        ):
            return False
        self.target_temperature = target_temperature
        self.indoor_temperature = indoor_temperature
        # Outdoor temperature isn't available locally on this model (the app
        # shows a cloud/weather value); avoid the bogus C0-derived value.
        self.outdoor_temperature = None
        return True


class CapabilityBody(NewProtocolMessageBody):
    """AC B5 capability response body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC B5 capability response message body."""
        super().__init__(body)

        params = self.parse()
        self._parse_capabilities(params)
        self.additional_capabilities = self._detect_additional_capabilities()

    def _detect_additional_capabilities(self) -> bool:
        """Return whether the device advertises a second capability frame.

        After parse() consumes every parameter, the body still holds a trailing
        [flag, message_id, crc] block. A non-zero flag means the device has more
        capabilities that only the additional (all_second_frame) query returns.
        The flag is read relative to parse()'s end position rather than a fixed
        offset so a body whose parameters are truncated is handled safely.
        """
        remaining = self.data[self._params_end_pos :]
        if len(remaining) < B5_ADDITIONAL_CAPABILITIES_TRAILER_LENGTH:
            return False
        return bool(remaining[-B5_ADDITIONAL_CAPABILITIES_TRAILER_LENGTH])

    def _parse_capabilities(  # noqa: C901
        self,
        params: dict[int, bytearray],
    ) -> None:
        """Decode capability values into feature flags.

        Parse capabilities using two strategies:
        1. Manual parsing for tags with special logic (mode, wind_speed, etc.)
        2. Auto-parse remaining tags using tag name as key and raw value

        Logs warnings for unknown tags not in CapabilityTag enum.
        """
        caps: dict[str, CapabilityValue] = {}

        # Temperature capability carries per-mode setpoint limits rather than a
        # flag. Decode the six raw half-degree bytes (cool/auto/heat, each a
        # min then a max) into a nested map keyed by mode name so the device
        # layer can resolve the min/max for the active mode. Dry and fan reuse
        # the cool range, so they are not stored separately. The decimals flag
        # indicates whether the device supports 0.5°C increments.
        if CapabilityTag.temperature in params:
            temp_data = params[CapabilityTag.temperature]
            # Skip temperature capability if data is too short to safely decode
            # all range and decimals fields (requires indices 0-5, plus decimals)
            if len(temp_data) < B5_TEMPERATURE_HEAT_MAX_INDEX + 1:
                _LOGGER.warning(
                    "Temperature capability data too short (%d bytes), skipping",
                    len(temp_data),
                )
            else:
                size = len(temp_data)
                decimals_index = (
                    B5_TEMPERATURE_DECIMALS_INDEX_LONG
                    if size > B5_TEMPERATURE_DECIMALS_SIZE_THRESHOLD
                    else B5_TEMPERATURE_DECIMALS_INDEX_SHORT
                )
                caps["temperature"] = {
                    "cool": {
                        "min": temp_data[B5_TEMPERATURE_COOL_MIN_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                        "max": temp_data[B5_TEMPERATURE_COOL_MAX_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                    },
                    "auto": {
                        "min": temp_data[B5_TEMPERATURE_AUTO_MIN_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                        "max": temp_data[B5_TEMPERATURE_AUTO_MAX_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                    },
                    "heat": {
                        "min": temp_data[B5_TEMPERATURE_HEAT_MIN_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                        "max": temp_data[B5_TEMPERATURE_HEAT_MAX_INDEX]
                        / B5_TEMPERATURE_HALF_DEGREE,
                    },
                    "decimals": temp_data[decimals_index] != 0,
                }

        # Manual parsing for tags with complex/special logic
        if CapabilityTag.mode in params:
            value = params[CapabilityTag.mode][0]
            modes = []
            if value in B5_HEAT_MODE_VALUES:
                modes.append("heat")
            if value not in B5_NO_COOL_MODE_VALUES:
                modes.append("cool")
            if value in B5_DRY_MODE_VALUES:
                modes.append("dry")
            if value in B5_AUTO_MODE_VALUES:
                modes.append("auto")
            caps["modes"] = modes

        if CapabilityTag.wind_swing in params:
            value = params[CapabilityTag.wind_swing][0]
            swing_modes = []
            if value in B5_SWING_HORIZONTAL_VALUES:
                swing_modes.append("horizontal")
            if value < B5_LOW_VALUE_MAX:
                swing_modes.append("vertical")
            caps["swing_modes"] = swing_modes

        if CapabilityTag.wind_speed in params:
            value = params[CapabilityTag.wind_speed][0]
            custom = value == B5_FAN_CUSTOM_VALUE
            fan_speeds = []
            if custom or value in B5_FAN_SILENT_VALUES:
                fan_speeds.append("silent")
            if custom or value in B5_FAN_LOW_HIGH_VALUES:
                fan_speeds.append("low")
            if custom or value in B5_FAN_MEDIUM_VALUES:
                fan_speeds.append("medium")
            if custom or value in B5_FAN_LOW_HIGH_VALUES:
                fan_speeds.append("high")
            if custom or value in B5_FAN_AUTO_VALUES:
                fan_speeds.append("auto")
            if custom:
                fan_speeds.append("custom")
            caps["fan_speeds"] = fan_speeds

        if CapabilityTag.eco in params:
            caps["eco"] = params[CapabilityTag.eco][0] in B5_ECO_VALUES

        if CapabilityTag.anion in params:
            caps["anion"] = params[CapabilityTag.anion][0] == B5_ANION_ON_VALUE

        if CapabilityTag.strong_wind in params:
            value = params[CapabilityTag.strong_wind][0]
            caps["turbo_cool"] = value < B5_LOW_VALUE_MAX
            caps["turbo_heat"] = value in B5_TURBO_HEAT_VALUES

        if CapabilityTag.screen_display_capability in params:
            caps["display_control"] = (
                params[CapabilityTag.screen_display_capability][0] in B5_DISPLAY_VALUES
            )

        if CapabilityTag.electricity in params:
            caps["rate_select"] = params[CapabilityTag.electricity][0]

        if CapabilityTag.self_clean in params:
            caps["self_clean"] = params[CapabilityTag.self_clean][0] > 0

        if CapabilityTag.ieco in params:
            ieco_data = params[CapabilityTag.ieco]
            ieco_start = ieco_data[0] if len(ieco_data) > 0 else 0
            ieco_end = ieco_data[1] if len(ieco_data) > 1 else 0
            caps["ieco"] = (
                ieco_start in B5_IECO_START_VALUES or ieco_end in B5_IECO_END_VALUES
            )

        if CapabilityTag.sound in params:
            # B5 advertises support; live sound state comes from B0/B1 bodies.
            caps["sound"] = True

        # Tags with special parsing logic (handled above).
        manually_parsed_tags = frozenset(
            {
                CapabilityTag.temperature,
                CapabilityTag.mode,
                CapabilityTag.wind_swing,
                CapabilityTag.wind_speed,
                CapabilityTag.eco,
                CapabilityTag.anion,
                CapabilityTag.strong_wind,
                CapabilityTag.screen_display_capability,
                CapabilityTag.electricity,
                CapabilityTag.self_clean,
                CapabilityTag.ieco,
                CapabilityTag.sound,
            },
        )

        # Auto-parse remaining tags that weren't manually handled above.
        for tag_id, raw in params.items():
            if tag_id in manually_parsed_tags:
                continue  # Already handled above

            try:
                tag_name = CapabilityTag(tag_id).name
            except ValueError:
                # Unknown tag entirely - not in CapabilityTag enum.
                _LOGGER.warning(
                    "Unknown capability tag in B5 response: 0x%04X, "
                    "Size: %d, Value: %s",
                    tag_id,
                    len(raw),
                    raw.hex(),
                )
                continue

            # Use the tag name as capability key and the first raw byte as its
            # value (0 -> falsy, >=1 -> truthy).
            caps[tag_name] = raw[0] if len(raw) > 0 else 0

        self.capabilities: dict[str, CapabilityValue] = caps


class StateBody(XMessageBody):
    """AC C0 message body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC C0 message body."""
        super().__init__(body)
        self.power = (body[1] & 0x1) > 0  # powerValue
        self.mode = (body[2] & 0xE0) >> 5  # modeValue
        target_temperature = (
            (body[2] & 0x0F) + 16.0 + (0.5 if body[0x02] & 0x10 > 0 else 0.0)
        )  # temperature + smallTemperature
        # C0 low-temperature replies keep 17/17.5 in byte 2 and store
        # 16/16.5 in byte 13.
        low_target_temperature = (
            body[LOW_TARGET_C0_EXTENSION_INDEX] & LOW_TARGET_TEMPERATURE_MASK
        )
        if (
            low_target_temperature == LOW_TARGET_C0_EXTENSION_VALUE
            and LOW_TARGET_TEMPERATURE_BOUNDARY
            <= target_temperature
            <= LOW_TARGET_C0_STANDARD_MAX
        ):
            target_temperature = (
                low_target_temperature
                + LOW_TARGET_TEMPERATURE_OFFSET
                + (target_temperature - LOW_TARGET_TEMPERATURE_BOUNDARY)
            )
        self.target_temperature = target_temperature
        self.fan_speed = body[3] & 0x7F  # fanspeedValue
        self.swing_vertical = (body[7] & 0x0C) > 0  # swingUDValue
        self.swing_horizontal = (body[7] & 0x03) > 0  # swingLRValue
        # strongWindValue
        self.boost_mode = ((body[8] & 0x20) > 0) or ((body[10] & 0x2) > 0)
        self.power_saving = (body[8] & POWER_SAVING_VALUE) > 0
        self.comfort_sleep = body[8] & 0x03  # comfortableSleepValue
        self.comfort_sleep_switch = body[9] & 0x40  # comfortableSleepSwitch
        self.pmv = (body[14] & 0x0F) * 0.5 - 3.5  # pmv
        self.smart_eye = (body[8] & 0x40) > 0
        self.natural_wind = (body[9] & 0x2) > 0  # naturalWind
        self.dry = (body[9] & 0x4) > 0  # dryValue
        self.eco_mode = (body[9] & 0x10) > 0  # ecoValue
        self.aux_heating = (body[9] & 0x08) > 0  # PTCValue
        self.purifier = body[9] & 0x20  # purifierValue
        self.anion = (body[9] & 0x20) > 0
        self.temp_fahrenheit = (body[10] & 0x04) > 0
        self.sleep_mode = (body[10] & 0x01) > 0
        decimal = body[15] if len(body) > TEMP_DECIMAL_MIN_BODY_LENGTH else 0
        self.indoor_temperature = self.parse_temperature(body[11], decimal & 0x0F)
        self.outdoor_temperature = self.parse_temperature(body[12], decimal >> 4)
        self.kick_quilt = (body[10] & 0x04) >> 2  # kickQuilt
        self.prevent_cold = (body[10] & 0x20) >> 5  # preventCold
        self.full_dust = ((body[13] & 0x20) >> 5) > 0  # dust_full_time
        # screenDisplayNowValue
        self.screen_display = (
            (body[14] >> 4 & 0x7) != SCREEN_DISPLAY_BYTE_CHECK
        ) and self.power
        # arom
        self.frost_protect = (
            (body[21] & 0x80) > 0 if len(body) >= FROST_PROTECT_MIN_LENGTH else False
        )
        # comfortPowerSave
        self.comfort_mode = (
            (body[22] & 0x1) > 0 if len(body) >= CONFORT_MODE_MIN_LENGTH2 else False
        )
        # smartDryValue
        self.smart_dry = (
            (body[19] & 0x7F) > 0 if len(body) >= SMART_DRY_MIN_LENGTH else False
        )
        # swingLRUnderSwitch
        self.swing_lr_switch = (
            body[19] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        )
        # swingLRValueUnder
        self.swing_lr_value = body[20] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        # Countdown timers, same slot layout as the 0x7e new-protocol payload.
        self.power_on_timer = parse_countdown_timer(
            body[C0_POWER_ON_TIMER_BYTE],
            body[C0_TIMER_MINUTE_CORRECTION_BYTE]
            >> NEW_PROTOCOL_TIMER_POWER_ON_CORRECTION_SHIFT,
        )
        self.power_off_timer = parse_countdown_timer(
            body[C0_POWER_OFF_TIMER_BYTE],
            body[C0_TIMER_MINUTE_CORRECTION_BYTE]
            & NEW_PROTOCOL_TIMER_MINUTE_CORRECTION_MASK,
        )
        if len(body) >= FRESH_AIR_C0_MIN_LENGTH:
            self.fresh_filter_time_total = body[25] * 256 + body[24]
            self.fresh_filter_time_use = body[27] * 256 + body[26]
            self.fresh_filter_timeout = (body[13] & 0x40) >> 6


class GroupBody(MessageBody):
    """AC C1 message body."""

    def __init__(self, body: bytearray, analysis_method: int = 3) -> None:
        """Initialize AC C1 message body."""
        super().__init__(body)
        if len(body) <= XC1_SUBBODY_TYPE_INDEX:
            return
        group_type = body[XC1_SUBBODY_TYPE_INDEX]
        if group_type == XC1_SUBBODY_TYPE_44:
            if len(body) < XC1_CONSUMPTION_MIN_LENGTH:
                return

            def parse_consumption(data: bytearray) -> float:
                return self.parse_consumption(analysis_method, data)

            # total_power_consumption
            self.total_energy_consumption = parse_consumption(body[4:8])
            # total_operating_consumption
            self.total_operating_consumption = parse_consumption(body[8:12])
            # current_operating_consumption
            self.current_energy_consumption = parse_consumption(body[12:16])
            # current_time_power
            self.realtime_power = self.parse_power(analysis_method, body[16:19])
        elif group_type == XC1_SUBBODY_TYPE_41:
            self._parse_group_one(body)
        elif group_type == XC1_SUBBODY_TYPE_42:
            self._parse_group_two(body)
        elif group_type == XC1_SUBBODY_TYPE_47:
            self._parse_group_seven(body)
        elif group_type == XC1_SUBBODY_TYPE_40:
            if len(body) < XC1_OPERATING_TIME_MIN_LENGTH:
                return
            self.electrify_time_day = body[5] | (body[4] << 8)
            self.electrify_time_hour = body[6]
            self.electrify_time_min = body[7]
            self.electrify_time_second = body[8]
            # summary
            self.electrify_time = (
                (self.electrify_time_day * 24)
                + self.electrify_time_hour
                + (self.electrify_time_min / 60)
                + (self.electrify_time_second / 3600)
            )
            self.total_operating_time_day = body[10] | (body[9] << 8)
            self.total_operating_time_hour = body[11]
            self.total_operating_time_min = body[12]
            self.total_operating_time_second = body[13]
            # summary
            self.total_operating_time = (
                (self.total_operating_time_day * 24)
                + self.total_operating_time_hour
                + (self.total_operating_time_min / 60)
                + (self.total_operating_time_second / 3600)
            )
            self.current_operating_time_day = body[15] | (body[14] << 8)
            self.current_operating_time_hour = body[16]
            self.current_operating_time_min = body[17]
            self.current_operating_time_second = body[18]
            # summary
            self.current_operating_time = (
                (self.current_operating_time_day * 24)
                + self.current_operating_time_hour
                + (self.current_operating_time_min / 60)
                + (self.current_operating_time_second / 3600)
            )
        elif group_type == XC1_SUBBODY_TYPE_45:
            if len(body) <= XC1_HUMIDITY_INDEX:
                return
            # indoor humidity, it should be the same value as XBB/XA1 message
            self.indoor_humidity = body[4] if body[4] != 0 else None
            if len(body) > XC1_DEFROST_INDEX:
                self.defrosting = body[XC1_DEFROST_INDEX] != 0

    def _parse_group_one(self, body: bytearray) -> None:
        """Parse group 1 data: compressor and refrigerant circuit.

        This is service/engineering data that the Midea app does not display,
        so it is not covered by any B5 capability and is simply absent on
        devices that do not answer the group 1 query.
        """
        if len(body) < XC1_GROUP_ONE_MIN_LENGTH:
            return
        self.compressor_frequency = body[4]
        self.target_compressor_frequency = body[5]
        self.compressor_current = body[7]
        self.compressor_voltage = body[8]
        # T1: indoor return air, T2: indoor coil
        self.indoor_ambient_temperature = (
            body[10] - XC1_TEMP_INDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        self.indoor_coil_temperature = (
            body[11] - XC1_TEMP_INDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        # T3: outdoor coil, T4: outdoor ambient
        self.outdoor_coil_temperature = (
            body[12] - XC1_TEMP_OUTDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        self.outdoor_ambient_temperature = (
            body[13] - XC1_TEMP_OUTDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        # TP: compressor discharge pipe, reported directly in degrees
        self.discharge_pipe_temperature = body[14]

    def _parse_group_two(self, body: bytearray) -> None:
        """Parse group 2 data: indoor fan and condensate pump."""
        if len(body) < XC1_GROUP_TWO_MIN_LENGTH:
            return
        self.target_indoor_fan_speed = body[4] * XC1_FAN_SPEED_FACTOR
        self.indoor_fan_speed = body[5] * XC1_FAN_SPEED_FACTOR
        # Could also be the float switch (tank full) that triggers the pump.
        self.water_pump_running = bool(body[8] & XC1_WATER_PUMP_MASK)

    def _parse_group_seven(self, body: bytearray) -> None:
        """Parse group 7 data: real time compressor power."""
        if len(body) < XC1_GROUP_SEVEN_MIN_LENGTH:
            return
        self.compressor_power = body[10] + (body[11] << 8)

    power_analysis_methods: Mapping[int, Callable[[int, int], int]] = MappingProxyType(
        {
            PowerFormats.BCD: lambda byte, value: (
                (byte >> 4) * 10 + (byte & 0x0F) + value * 100
            ),
            PowerFormats.BINARY: lambda byte, value: byte + (value << 8),
            PowerFormats.MIXED: lambda byte, value: byte + value * 100,
        },
    )

    @classmethod
    def parse_value(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse value."""
        if analysis_method not in PowerFormats._value2member_map_:
            return 0.0  # unknown method
        analysis_function = cls.power_analysis_methods[analysis_method % 10]
        value = 0
        for byte in databytes:
            value = analysis_function(byte, value)
        return float(value)

    @classmethod
    def parse_power(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse power."""
        if analysis_method == PowerFormats.BCD_ENERGY_BINARY_POWER:
            return cls.parse_value(PowerFormats.BINARY, databytes) / 10
        return cls.parse_value(analysis_method, databytes) / 10

    @classmethod
    def parse_consumption(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse consumption."""
        if analysis_method == PowerFormats.BCD_ENERGY_BINARY_POWER:
            return cls.parse_value(PowerFormats.BCD, databytes) / 100
        # LSB = 0.01 kWh, except for default binary format = 0.1 kWh
        divisor = 10 if analysis_method == PowerFormats.BINARY else 100
        return cls.parse_value(analysis_method, databytes) / divisor


class SubProtocolBody(MessageBody):
    """AC BB message body."""

    def __init__(self, body: bytearray) -> None:
        """Initializ AC BB message body."""
        super().__init__(body)
        subprotocol_head = body[:6]
        subprotocol_body = body[6:]
        data_type = subprotocol_head[-1]
        subprotocol_body_len = len(subprotocol_body)
        if (
            data_type in (ListTypes.X11, ListTypes.X20)
            and subprotocol_body_len > BB_BASIC_FAN_SPEED_INDEX
        ):
            self.power = (subprotocol_body[0] & 0x1) > 0
            self.dry = (subprotocol_body[0] & 0x10) > 0
            self.boost_mode = (subprotocol_body[0] & 0x20) > 0
            self.aux_heating = (subprotocol_body[1] & 0x40) > 0
            self.sleep_mode = (subprotocol_body[2] & 0x80) > 0
            try:
                self.mode = BB_AC_MODES.index(subprotocol_body[5] + 1)
            except ValueError:
                self.mode = 0
            self.target_temperature = (subprotocol_body[6] - 30) / 2
            self.fan_speed = subprotocol_body[7]
            self.timer = (
                (subprotocol_body[25] & 0x04) > 0
                if subprotocol_body_len > TIMER_MIN_SUBPROTOCOL_LENGTH
                else False
            )
            self.eco_mode = (
                (subprotocol_body[25] & 0x40) > 0
                if subprotocol_body_len > ECO_MODE_MIN_SUBPROTOCOL_LENGTH
                else False
            )
            # These offsets are known for the verified BB fresh-air model; the
            # device layer gates public attributes and controls to that model.
            if subprotocol_body_len > BB_FRESH_AIR_EXHAUST_SPEED_INDEX:
                fresh_air_switches = subprotocol_body[BB_FRESH_AIR_SWITCH_INDEX]
                self.bb_fresh_air_power = bool(
                    fresh_air_switches & BB_FRESH_AIR_INTAKE_STATUS_MASK,
                )
                self.bb_fresh_air_fan_speed = subprotocol_body[
                    BB_FRESH_AIR_INTAKE_SPEED_INDEX
                ]
                self.bb_fresh_air_exhaust_power = bool(
                    fresh_air_switches & BB_FRESH_AIR_EXHAUST_STATUS_MASK,
                )
                self.bb_fresh_air_exhaust_speed = subprotocol_body[
                    BB_FRESH_AIR_EXHAUST_SPEED_INDEX
                ]
        elif data_type == ListTypes.X10:
            if subprotocol_body_len > BB_INDOOR_TEMPERATURE_HIGH_INDEX:
                if subprotocol_body[8] & 0x80 == SUB_PROTOCOL_BODY_TEMP_CHECK:
                    self.indoor_temperature = (
                        0 - (~(subprotocol_body[7] + subprotocol_body[8] * 256) + 1)
                        & 0xFFFF
                    ) / 100
                else:
                    self.indoor_temperature = (
                        subprotocol_body[7] + subprotocol_body[8] * 256
                    ) / 100
            if subprotocol_body_len > BB_INDOOR_HUMIDITY_INDEX:
                self.indoor_humidity = (
                    subprotocol_body[30] if subprotocol_body[30] != 0 else None
                )
            if subprotocol_body_len > BB_SN8_FLAG_INDEX:
                self.sn8_flag = subprotocol_body[80] == XBB_SN8_BYTE_FLAG
        elif data_type == ListTypes.X12:
            pass
        elif data_type == ListTypes.X30:
            if subprotocol_body_len > BB_OUTDOOR_TEMPERATURE_HIGH_INDEX:
                if subprotocol_body[6] & 0x80 == SUB_PROTOCOL_BODY_TEMP_CHECK:
                    self.outdoor_temperature = (
                        0 - (~(subprotocol_body[5] + subprotocol_body[6] * 256) + 1)
                        & 0xFFFF
                    ) / 100
                else:
                    self.outdoor_temperature = (
                        subprotocol_body[5] + subprotocol_body[6] * 256
                    ) / 100
            if subprotocol_body_len > BB_COMPRESSOR_FREQUENCY_INDEX:
                self.target_compressor_frequency = subprotocol_body[
                    BB_COMPRESSOR_TARGET_FREQUENCY_INDEX
                ]
                self.compressor_frequency = subprotocol_body[
                    BB_COMPRESSOR_FREQUENCY_INDEX
                ]
        elif data_type in (ListTypes.X13, ListTypes.X21):
            pass


class MessageACResponse(MessageResponse):
    """AC message response."""

    # Populated dynamically by MessageResponse.set_attr().
    degerming_active: bool
    light_sensitive_active: bool
    power_on_timer: int
    power_off_timer: int
    self_clean_active: bool

    def __init__(
        self,
        message: bytearray,
        power_analysis_method: int = 3,
        new_protocol_temperature: bool = False,
    ) -> None:
        """Initialize AC message response."""
        super().__init__(message)
        # dataType 0x05 and messageBytes[0] 0xA0
        if self.message_type == MessageType.notify2 and self.body_type == ListTypes.A0:
            if len(super().body) < A0_A1_C0_MIN_BODY_LENGTH:
                _LOGGER.debug(
                    "Skipping A0 body too short to parse (%d < %d bytes): %s",
                    len(super().body),
                    A0_A1_C0_MIN_BODY_LENGTH,
                    super().body.hex(),
                )
            else:
                self.set_body(XA0Body(super().body))
        # dataType 0x04 and messageBytes[0] 0xA1
        elif (
            self.message_type == MessageType.notify1 and self.body_type == ListTypes.A1
        ):
            if len(super().body) < A0_A1_C0_MIN_BODY_LENGTH:
                _LOGGER.debug(
                    "Skipping notify1 A1 body too short to parse (%d < %d bytes): %s",
                    len(super().body),
                    A0_A1_C0_MIN_BODY_LENGTH,
                    super().body.hex(),
                )
            else:
                self.set_body(XA1Body(super().body))
        # parse CapabilitiesQuery/CapabilitiesAdditionalQuery response
        # dataType 0x03 and messageBytes[0] 0xB5
        elif self.message_type == MessageType.query and self.body_type == ListTypes.B5:
            self.set_body(CapabilityBody(super().body))
        # dataType 0x05 and messageBytes[0] 0xB5
        # dataType 0x02 and messageBytes[0] 0xB0 (set result Unidentified protocol)
        # dataType 0x03 and messageBytes[0] 0xB1
        elif self.message_type in [
            MessageType.query,
            MessageType.set,
            MessageType.notify2,
        ] and self.body_type in [ListTypes.B0, ListTypes.B1, ListTypes.B5]:
            self.set_body(
                PropertiesBody(super().body, new_protocol_temperature),
            )
        # dataType 0x02 and messageBytes[0] 0xC0
        # dataType 0x03 and messageBytes[0] 0xC0
        elif (
            self.message_type in [MessageType.query, MessageType.set]
            and self.body_type == ListTypes.C0
        ):
            if len(super().body) < A0_A1_C0_MIN_BODY_LENGTH:
                _LOGGER.debug(
                    "Skipping C0 body too short to parse (%d < %d bytes): %s",
                    len(super().body),
                    A0_A1_C0_MIN_BODY_LENGTH,
                    super().body.hex(),
                )
            else:
                self.set_body(StateBody(super().body))
        # messageBytes[0] 0xC1
        elif self.message_type == MessageType.query and self.body_type == ListTypes.C1:
            self.set_body(GroupBody(super().body, power_analysis_method))
        elif (
            self.message_type
            in [MessageType.set, MessageType.query, MessageType.notify2]
            and self.body_type == ListTypes.BB
            and len(super().body) >= BB_MIN_BODY_LENGTH
        ):
            self.used_subprotocol = True
            self.set_body(SubProtocolBody(super().body))

        self.set_attr()
