"""Midea lan lib."""
