"""Midea Lan cloud."""

import base64
import json
import logging
import re
import time
from asyncio import Lock
from collections.abc import Mapping
from datetime import UTC, datetime
from http import HTTPStatus
from pathlib import Path
from secrets import token_hex
from typing import Any, cast

import aiofiles
from aiohttp import ClientConnectionError, ClientError, ClientSession, ClientTimeout

from midealan.exceptions import CloudAuthError, CloudError, ElementMissing

from .security import (
    CloudSecurity,
    MeijuCloudSecurity,
    MideaAirSecurity,
    MSmartCloudSecurity,
    ToshibaIOLifeSecurity,
)

SN8_MIN_SERIAL_LENGTH = 17

# E3 gas water heaters report water and gas consumption only in the cloud: the
# official app requests the dayReportV2 usage report through the per-cloud
# proxy alias below, authenticated with the user access token (the LAN
# token/key are rejected).
DAY_REPORT_ALIAS = "/cfhrs/e3/v1/api"
DAY_REPORT_MESSAGE = "dayReportV2"
DAY_REPORT_TIMEOUT = ClientTimeout(20)
# Codes the gateway answers when the access token is missing, rejected or not a
# user token; callers log in again instead of retrying the same token.
AUTH_ERROR_CODES = frozenset({40001, 40002, 44001})

_LOGGER = logging.getLogger(__name__)

SUPPORTED_CLOUDS: dict[str, Any] = {
    "美的美居": {
        "class_name": "MeijuCloud",
        "app_id": "900",
        "app_key": "46579c15",
        "login_key": "ad0ee21d48a64bf49f4fb583ab76e799",
        "iot_key": bytes.fromhex(
            format(9795516279659324117647275084689641883661667, "x"),
        ).decode(),
        "hmac_key": bytes.fromhex(
            format(117390035944627627450677220413733956185864939010425, "x"),
        ).decode(),
        "api_url": "https://mp-prod.smartmidea.net/mas/v5/app/proxy?alias=",
    },
    "SmartHome": {
        "class_name": "SmartHomeCloud",
        "app_id": "1010",
        "app_key": "ac21b9f9cbfe4ca5a88562ef25e2b768",
        "iot_key": bytes.fromhex(format(7882822598523843940, "x")).decode(),
        "hmac_key": bytes.fromhex(
            format(117390035944627627450677220413733956185864939010425, "x"),
        ).decode(),
        "api_url": "https://mp-prod.appsmb.com/mas/v5/app/proxy?alias=",
    },
    "Midea Air": {
        "class_name": "MideaAirCloud",
        "app_id": "1117",
        "app_key": "ff0cf6f5f0c3471de36341cab3f7a9af",
        "api_url": "https://mapp.appsmb.com",  # codespell:ignore
    },
    "NetHome Plus": {
        "default": True,
        "class_name": "MideaAirCloud",
        "app_id": "1017",
        "app_key": "3742e9e5842d4ad59c2db887e12449f9",
        "api_url": "https://mapp.appsmb.com",  # codespell:ignore
    },
    "Ariston Clima": {
        "class_name": "MideaAirCloud",
        "app_id": "1005",
        "app_key": "434a209a5ce141c3b726de067835d7f0",
        "api_url": "https://mapp.appsmb.com",  # codespell:ignore
    },
    # TSmartLife (Toshiba's "oversea"/non-Japan-domestic market app,
    # com.midea.ai.toshiba.oversea.inhouse) for the GR-RF900WI-PMV(06)-MG
    # refrigerator (device type 0xCA). Confirmed a separate cloud
    # deployment from Toshiba's other app, IOLife (see "Toshiba Iolife"
    # entry below) -- two unrelated TSmartLife accounts were both
    # rejected with code 3102 when pointed at IOLife's endpoint; see
    # home-assistant/core#182840.
    #
    # api_url is REAL, confirmed via three independent methods on
    # 2026-10-10: (1) a literal string match in the TSmartLife APK's
    # classes.dex, (2) a live PCAPdroid capture of the real app connecting
    # to this exact host, (3) DNS/TLS inspection (resolves to an Alibaba
    # Cloud ALB, ap-southeast-1; TLS cert verifies OK). The URL/path shape
    # (`/mas/v5/app/proxy?alias=`) matches SmartHomeCloud's convention
    # exactly -- hence class_name below reuses SmartHomeCloud's flow via a
    # thin subclass.
    #
    # app_id/app_key/iot_key/hmac_key below are the 4 shared, app-level
    # constants every copy of the TSmartLife "oversea" app ships with --
    # NOT personal account credentials, NOT a specific user's login, and
    # NOT any individual appliance's LAN token/key (those remain
    # per-user/per-device and are never published anywhere). Confirmed,
    # against a real production Toshiba GR-RF900WI-PMV(06)-MG fridge,
    # that this exact class, unmodified, successfully authenticates,
    # discovers the appliance, and returns a LAN V3 token/key pair that
    # midea_ac_lan uses for live local control (see issue #364 for the
    # full investigation). These 4 values are taken directly from the
    # maintainer-approved published default at
    # https://github.com/jaspweowaale/toshiba-tsmartlife-local/blob/main/src/toshiba_tsmartlife_local/vietnam_defaults.py
    # -- see that repo's docs/APP_CREDENTIAL_SECURITY.md for the full
    # classification/risk analysis behind publishing them. Direct
    # precedent: SUPPORTED_CLOUDS above already publishes 5 other
    # clouds' equivalent 4 constants in plaintext the same way.
    "TSmartLife": {
        "class_name": "TSmartLifeCloud",
        "app_id": "1020",
        "app_key": "d1ba2a7513bef7bbcd58478b678ff655",
        "iot_key": "meicloud",
        "hmac_key": "PROD_VnoClJI9aikS8dyy",
        "api_url": "https://mp-jp-prod.appsmb.com/mas/v5/app/proxy?alias=",
        # 0008 is Toshiba's manufacturer/enterprise code (shipped in-app
        # as APP_ENTERPRISE, prefixes every T_0008_* Lua protocol file --
        # this device's family: T_0008_CA_{21,22,24,25,27,28,29}.lua).
        "manufacturer_code": "0008",
    },
    "Toshiba Iolife": {
        "class_name": "ToshibaIOLife",
        "app_id": "1203",
        "app_key": "09c4d09f0da1513bb62dc7b6b0af9c11",
        "api_url": "https://app.iolife.toshiba-lifestyle.com",
        "app_version": "3.4.0",
        # The API does not return an enterpriseCode, so this is the fallback.
        # 0x0008 is Toshiba's code: the app ships it as APP_ENTERPRISE
        # and it prefixes every T_0008_* protocol file.
        "manufacturer_code": "0008",
    },
}

DEFAULT_KEYS = {
    99: {
        "token": "ee755a84a115703768bcc7c6c13d3d629aa416f1e2fd798beb9f78cbb1381d09"
        "1cc245d7b063aad2a900e5b498fbd936c811f5d504b2e656d4f33b3bbc6d1da3",
        "key": "ed37bd31558a4b039aaf4e7a7a59aa7a75fd9101682045f69baf45d28380ae5c",
    },
}

PRESET_ACCOUNT_DATA = [
    39182118275972017797890111985649342047468653967530949796945843010512,
    39182118275980892824833804202177448991093361348247890162501600564413,
    39182118275972017797890111985649342050088014265865102175083010656997,
]


def get_default_cloud() -> str:
    """Return default cloud."""
    for key, value in SUPPORTED_CLOUDS.items():
        if value.get("default"):
            return key
    raise ElementMissing


def get_preset_account_cloud() -> dict[str, str]:
    """Return preset account data for cloud login."""
    username: str = bytes.fromhex(
        format((PRESET_ACCOUNT_DATA[0] ^ PRESET_ACCOUNT_DATA[1]), "X"),
    ).decode("utf-8", errors="ignore")
    password: str = bytes.fromhex(
        format((PRESET_ACCOUNT_DATA[0] ^ PRESET_ACCOUNT_DATA[2]), "X"),
    ).decode("utf-8", errors="ignore")

    return {
        "username": username,
        "password": password,
        "cloud_name": get_default_cloud(),
    }


block = "*"


def _mask_token(token: str) -> str:
    """Mask token but keep first 5 chars."""
    if not token:
        return token

    visible = token[:5]
    return visible + block * max(0, len(token) - len(visible))


def _redact_data(data: str) -> str:
    """Redact sensitive data."""
    # Mask the values of ``token`` and ``key`` fields first: these carry the
    # LAN credentials, so a raw getToken response must never reach the log in
    # full. Handles both JSON (``"token": "abc"``) and dict-repr (``'key': 'abc'``)
    # shapes that reach this function via ``str(raw)`` / ``str(data)``.
    data = re.sub(
        r"(['\"](?:token|key)['\"]\s*:\s*['\"])([^'\"]+)(['\"])",
        lambda m: m.group(1) + _mask_token(m.group(2)) + m.group(3),
        data,
        flags=re.IGNORECASE,
    )
    patterns = [
        # Email
        r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        # Phone number
        r"(?:\+?\d{1,3})?[-.\s]?(?:\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{4}",
        # Credit card
        r"\b(?:\d[ -]*?){13,19}\b",
        # BTC address
        r"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b",
        # IPv4
        r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        # Simple street address
        (
            r"\b\d{1,5}\s+[A-Za-z0-9\s]{3,40}"
            r"(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Way|Boulevard|Blvd)\b"
        ),
    ]

    for pattern in patterns:
        data = re.sub(
            pattern,
            lambda m: _mask_token(m.group(0)),
            data,
            flags=re.IGNORECASE,
        )

    return data


def _day_report_error(code: object, message: object) -> CloudError:
    """Return the error matching a dayReportV2 error payload."""
    error_code = code if isinstance(code, int) else -1
    text = f"{error_code}: {message}"
    if error_code in AUTH_ERROR_CODES:
        return CloudAuthError(text)
    return CloudError(text)


def _parse_token_list(
    response: dict[str, Any] | None,
    udp_id: str | None,
) -> dict[str, str] | None:
    """Return the last matching token/key pair without logging credentials."""
    tokens = (response or {}).get("tokenlist") or []
    _LOGGER.debug("get_cloud_keys() returned %s token entries", len(tokens))
    result = None
    for token in tokens:
        if token["udpId"] == udp_id:
            result = {
                "token": token["token"].lower(),
                "key": token["key"].lower(),
            }
    return result


class MideaCloud:
    """Midea Cloud."""

    def __init__(
        self,
        session: ClientSession,
        security: CloudSecurity,
        app_id: str,
        app_key: str,
        account: str,
        password: str,
        api_url: str,
    ) -> None:
        """Initialize Midea Cloud."""
        self._device_id = CloudSecurity.get_deviceid(account)
        self._session = session
        self._security = security
        self._api_lock = Lock()
        self._app_id = app_id
        self._app_key = app_key
        self._account = account
        self._password = password
        self._api_url = api_url
        self._access_token: str | None = None
        self._uid: str | None = None
        self._login_id = ""

    def _make_general_data(self) -> dict[Any, Any]:
        return {}

    async def _api_request(
        self,
        endpoint: str,
        data: dict[str, Any],
        header: dict[str, Any] | None = None,
    ) -> dict | None:
        header = header or {}
        if not data.get("reqId"):
            data.update({"reqId": token_hex(16)})
        if not data.get("stamp"):
            data.update(
                {"stamp": datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S")},
            )
        random = str(int(time.time()))
        url = self._api_url + endpoint
        dump_data = json.dumps(data)
        sign = self._security.sign("", dump_data, random)
        header.update(
            {
                "content-type": "application/json; charset=utf-8",
                "secretVersion": "1",
                "sign": sign,
                "random": random,
            },
        )
        if self._uid is not None:
            header.update({"uid": self._uid})
        if self._access_token is not None:
            header.update({"accessToken": self._access_token})
        response: dict = {"code": -1}
        for _ in range(3):
            try:
                async with self._api_lock:
                    r = await self._session.request(
                        "POST",
                        url,
                        headers=header,
                        data=dump_data,
                        timeout=ClientTimeout(10),
                    )
                    raw = await r.read()
                    _LOGGER.debug(
                        "Midea cloud API url: %s, \n data: %s, \n response: %s",
                        url,
                        _redact_data(str(data)),
                        _redact_data(str(raw)),
                    )
                    response = json.loads(raw)
                    break
            except (TimeoutError, ClientConnectionError, json.JSONDecodeError) as e:
                _LOGGER.warning(
                    "Midea cloud API error, url: %s, error: %s",
                    url,
                    repr(e),
                )
        if int(response["code"]) == 0 and "data" in response:
            return cast("dict", response["data"])
        return None

    async def _get_login_id(self) -> str | None:
        data = self._make_general_data()
        data.update({"loginAccount": f"{self._account}"})
        if response := await self._api_request(
            endpoint="/v1/user/login/id/get",
            data=data,
        ):
            return response.get("loginId")
        return None

    async def login(self) -> bool:
        """Authenticate."""
        raise NotImplementedError

    @staticmethod
    async def get_default_keys() -> dict[int, dict[str, Any]]:
        """Get default cloud keys."""
        return DEFAULT_KEYS

    async def get_cloud_keys(self, appliance_id: int) -> dict[int, dict[str, Any]]:
        """Get keys for device."""
        result = {}
        for method in [1, 2]:
            udp_id = self._security.get_udp_id(appliance_id, method)
            data = self._make_general_data()
            # The MSmartHome ("SmartHome") cloud rejects getToken with
            # 3004 "value is illegal" unless the appliance id is also sent as
            # `applianceCodes`; the official app includes it. Harmless on other
            # clouds, which ignore the extra field.
            data.update({"udpid": udp_id, "applianceCodes": str(appliance_id)})
            response = await self._api_request(
                endpoint="/v1/iot/secure/getToken",
                data=data,
            )
            if keys := _parse_token_list(response, udp_id):
                result[method] = keys
        return result

    @staticmethod
    async def get_cloud_servers() -> dict[int, str]:
        """Get available cloud servers."""
        return {i: cloud for i, cloud in enumerate(SUPPORTED_CLOUDS, start=1)}

    async def list_home(self) -> dict[int, Any] | None:
        """List homes."""
        return {1: "My home"}

    async def list_appliances(
        self,
        home_id: str | None,
    ) -> dict[int, dict[str, Any]] | None:
        """List appliances."""
        raise NotImplementedError

    async def get_device_info(self, device_id: int) -> dict[str, Any] | None:
        """Get device information."""
        if (response := await self.list_appliances(home_id=None)) and (
            int(device_id) in response
        ):
            return cast("dict", response[device_id])
        return None

    def set_access_token(self, access_token: str) -> None:
        """Use an externally obtained access token instead of logging in."""
        self._access_token = access_token

    async def get_day_report(self, appliance_id: int) -> dict[str, Any] | None:
        """Get the dayReportV2 usage report of an appliance.

        The report is served by the per-cloud proxy under
        :data:`DAY_REPORT_ALIAS` and requires a user access token: the LAN
        ``token``/``key`` are rejected with 40002.

        Returns
        -------
        dict[str, Any] | None
            The raw report result, or None when the cloud holds no report for
            the appliance.

        Raises
        ------
        CloudAuthError
            If no access token is available or the cloud rejected it.
        CloudError
            If the cloud does not provide usage reports, could not be reached,
            or answered with an error.

        """
        if not self._access_token:
            msg = "No Midea cloud access token"
            raise CloudAuthError(msg)
        if "alias=" not in self._api_url:
            msg = f"Cloud {self._api_url} does not provide usage reports"
            raise CloudError(msg)
        url = f"{self._api_url}{DAY_REPORT_ALIAS}"
        headers = {
            "content-type": "application/json; charset=utf-8",
            "accessToken": self._access_token,
        }
        payload = {
            "msg": DAY_REPORT_MESSAGE,
            "params": {"applianceId": str(appliance_id)},
        }
        try:
            async with self._api_lock:
                response = await self._session.request(
                    "POST",
                    url,
                    headers=headers,
                    json=payload,
                    timeout=DAY_REPORT_TIMEOUT,
                    allow_redirects=False,
                )
                data: Any = await response.json(content_type=None)
        except (ClientError, TimeoutError, ValueError) as err:
            msg = f"Midea cloud usage report request failed: {err}"
            raise CloudError(msg) from err
        if not isinstance(data, dict):
            msg = f"Unexpected Midea cloud usage report response: {type(data).__name__}"
            raise CloudError(msg)
        error_code = data.get("code")
        if error_code is not None:
            raise _day_report_error(error_code, data.get("msg", ""))
        if str(data.get("retCode")) != "0":
            raise _day_report_error(0, data.get("desc", data.get("retCode")))
        result = data.get("result")
        return result if isinstance(result, dict) else None

    @staticmethod
    def _get_lua_download_metadata(
        path: str,
        response: dict[str, Any],
        sn: str,
    ) -> tuple[str, Path] | None:
        """Validate lua download metadata and build a safe destination path."""
        url = response.get("url")
        file_name_value = response.get("fileName")
        file_name = (
            Path(file_name_value).name if isinstance(file_name_value, str) else ""
        )
        if not isinstance(url, str) or not url or file_name in {"", ".."}:
            _LOGGER.warning("Invalid lua metadata for appliance %s.", sn)
            return None
        return url, Path(path) / file_name

    async def download_lua(
        self,
        path: str,
        device_type: int,
        sn: str,
        model_number: str | None = None,
        manufacturer_code: str = "0000",
    ) -> str | None:
        """Download lua integration."""
        raise NotImplementedError

    async def download_plugin(
        self,
        path: str,
        device_type: int,
        sn: str,
    ) -> str | None:
        """Download lua integration."""
        raise NotImplementedError


class MeijuCloud(MideaCloud):
    """Meiju Cloud."""

    def __init__(
        self,
        cloud_name: str,
        session: ClientSession,
        account: str,
        password: str,
    ) -> None:
        """Initialize Meiju Cloud."""
        cloud_data = SUPPORTED_CLOUDS[cloud_name]
        super().__init__(
            session=session,
            security=MeijuCloudSecurity(
                login_key=cloud_data["login_key"],
                iot_key=cloud_data["iot_key"],
                hmac_key=cloud_data["hmac_key"],
            ),
            app_id=cloud_data["app_id"],
            app_key=cloud_data["app_key"],
            account=account,
            password=password,
            api_url=cloud_data["api_url"],
        )

    def _make_general_data(self) -> dict[str, Any]:
        return {
            "src": self._app_id,
            "format": "2",
            "stamp": datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S"),
            "platformId": "1",
            "deviceId": self._device_id,
            "reqId": token_hex(16),
            "uid": self._uid,
            "clientType": "1",
            "appId": self._app_id,
            "language": "en_US",
        }

    async def login(self) -> bool:
        """Authenticate to Meiju Cloud."""
        if login_id := await self._get_login_id():
            self._login_id = login_id
            stamp = datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S")
            data = {
                "iotData": {
                    "clientType": 1,
                    "deviceId": self._device_id,
                    "iampwd": self._security.encrypt_iam_password(
                        self._login_id,
                        self._password,
                    ),
                    "iotAppId": self._app_id,
                    "loginAccount": self._account,
                    "password": self._security.encrypt_password(
                        self._login_id,
                        self._password,
                    ),
                    "reqId": token_hex(16),
                    "stamp": stamp,
                },
                "data": {
                    "appKey": self._app_key,
                    "deviceId": self._device_id,
                    "platform": 2,
                },
                "timestamp": stamp,
                "stamp": stamp,
            }
            if response := await self._api_request(
                endpoint="/mj/user/login",
                data=data,
            ):
                self._access_token = response["mdata"]["accessToken"]
                self._security.set_aes_keys(
                    self._security.aes_decrypt_with_fixed_key(response["key"]),
                    b"0",
                )

                return True
        _LOGGER.warning("Meiju Cloud login failed for device %s", self._device_id)
        return False

    async def list_home(self) -> dict[int, Any] | None:
        """List Meiju Cloud homes."""
        if response := await self._api_request(
            endpoint="/v1/homegroup/list/get",
            data={},
        ):
            homes = {}
            for home in response["homeList"]:
                homes.update({int(home["homegroupId"]): home["name"]})
            return homes
        return None

    async def get_cloud_keys(self, appliance_id: int) -> dict[int, dict[str, Any]]:
        """Get keys for device from the Meiju cloud.

        Meiju retired the `/v1/iot/secure/getToken` endpoint the base class uses:
        its gateway now answers `{"code": 40404}` / "the access address does not
        exist", so no keys come back at all and every V3 device fails to
        authenticate with "Can't get available token from Midea server".

        The replacement is `/v2/iot/secure/getToken`, which additionally requires
        `homegroupId` and expects `applianceCodes` as a list -- passing the plain
        string the v1 endpoint accepted makes it answer `1002 none parameter is
        found`.

        Falls back to the inherited v1 implementation when v2 yields nothing, so
        this stays a no-op for clouds or accounts the old endpoint still serves.
        """
        homes = await self.list_home()
        result: dict[int, dict[str, Any]] = {}
        for home_id in homes or {}:
            for method in [1, 2]:
                udp_id = self._security.get_udp_id(appliance_id, method)
                data = self._make_general_data()
                data.update(
                    {
                        "homegroupId": str(home_id),
                        "udpid": udp_id,
                        "applianceCodes": [str(appliance_id)],
                    },
                )
                response = await self._api_request(
                    endpoint="/v2/iot/secure/getToken",
                    data=data,
                )
                if keys := _parse_token_list(response, udp_id):
                    result[method] = keys
            if result:
                break
        if not result:
            _LOGGER.debug(
                "v2 getToken returned no keys for appliance_id %s, "
                "falling back to the v1 endpoint",
                appliance_id,
            )
            return await super().get_cloud_keys(appliance_id)
        return result

    async def list_appliances(
        self,
        home_id: str | None,
    ) -> dict[int, dict[str, Any]] | None:
        """List Meiju Cloud devices."""
        data = {"homegroupId": home_id}
        if response := await self._api_request(
            endpoint="/v1/appliance/home/list/get",
            data=data,
        ):
            appliances = {}
            for home in response.get("homeList") or []:
                for room in home.get("roomList") or []:
                    for appliance in room.get("applianceList"):
                        try:
                            model_number = int(appliance.get("modelNumber", 0))
                        except (ValueError, TypeError):
                            model_number = 0
                        device_info = {
                            "name": appliance.get("name"),
                            "type": int(appliance.get("type"), 16),
                            "sn": (
                                self._security.aes_decrypt(appliance.get("sn"))
                                if appliance.get("sn")
                                else ""
                            ),
                            "sn8": appliance.get("sn8", "00000000"),
                            "model_number": model_number,
                            "manufacturer_code": appliance.get(
                                "enterpriseCode",
                                "0000",
                            ),
                            "model": appliance.get("productModel"),
                            "online": appliance.get("onlineStatus") == "1",
                        }
                        sn8 = device_info.get("sn8")
                        if not sn8 or len(sn8) == 0:
                            device_info["sn8"] = "00000000"
                        model = device_info.get("model")
                        if not model or len(model) == 0:
                            device_info["model"] = device_info["sn8"]
                        appliances[int(appliance["applianceCode"])] = device_info
            return appliances
        return None

    async def get_device_info(self, device_id: int) -> dict[str, Any] | None:
        """Get device information.

        API url: https://mp-prod.smartmidea.net/mas/v5/app/proxy?alias=/v1/appliance/info/get
        header:
        input: {'applianceCode': 21000***830**18,
            'reqId': 'b11bb9083be6d77906fe1c9f019cdea0', 'stamp': '20240710092728'}
        response: b'{"code":0,"msg":null,"data":{"id":null,
            "applianceCode":21000***830**18,
            "sn":"7105f17f36a6afcce272f8053e2be60fd74b1a4baca120afaad83011bb50e8d5f3678bf88e32ea11885394e1a32c9c0e",
            "onlineStatus":1,"type":"0xDB","modelNumber":"12877",
            "name":"device_name_bytearray",
            "des":null,"activeStatus":1,"activeTime":"2024-06-12 10:45:45",
            "masterId":null,"wifiVersion":"059009012205","enterprise":"0000",
            "isOtherEquipment":null,"attrs":null,"roomName":null,
            "btMac":"54B8740FA801","btToken":null,"hotspotName":null,
            "isBluetooth":0,"bindType":null,"ability":null,"nameChanged":null,
            "sn8":"38127874","supportWot":false,"templateOfTSL":null,
            "shadowLevel":null,"smartProductId":10004256,"brand":null}}'
        """
        data = {"applianceCode": device_id}
        if response := await self._api_request(
            endpoint="/v1/appliance/info/get",
            data=data,
        ):
            try:
                model_number = int(response.get("modelNumber", 0))
            except (ValueError, TypeError):
                model_number = 0
            model_type = response.get("type")
            device_info = {
                "name": response.get("name"),
                "type": int(model_type, 16) if model_type else 0,
                "sn": self._security.aes_decrypt(response.get("sn") or ""),
                "sn8": response.get("sn8", "00000000"),
                "model_number": model_number,
                "manufacturer_code": response.get("enterpriseCode", "0000"),
                "model": response.get("productModel"),
                "online": response.get("onlineStatus") == "1",
                "des": response.get("des", None),
                "active_status": response.get("activeStatus", None),
                "active_time": response.get("activeTime", None),
                "master_id": response.get("masterId", None),
                "wifi_version": response.get("wifiVersion", None),
                "enterprise": response.get("enterprise", None),
                "is_other_equipment": response.get("isOtherEquipment", None),
                "attrs": response.get("attrs", None),
                "room_name": response.get("roomName", None),
                "bt_mac": response.get("btMac", None),
                "bt_token": response.get("btToken", None),
                "hotspot_name": response.get("hotspotName", None),
                "is_bluetooth": response.get("isBluetooth", None),
                "bind_type": response.get("bindType", None),
                "ability": response.get("ability", None),
                "name_changed": response.get("nameChanged", None),
                "support_wot": response.get("supportWot", None),
                "template_of_tsl": response.get("templateOfTSL", None),
                "shadow_level": response.get("shadowLevel", None),
                "smart_product_id": response.get("smartProductId", None),
                "brand": response.get("brand", None),
            }
            sn8 = device_info.get("sn8")
            if sn8 is None or len(sn8) == 0:
                device_info["sn8"] = "00000000"
            model = device_info.get("model")
            if model is None or len(model) == 0:
                device_info["model"] = device_info["sn8"]
            return device_info
        return None

    async def download_lua(
        self,
        path: str,
        device_type: int,
        sn: str,
        model_number: str | None = None,  # noqa: ARG002
        manufacturer_code: str = "0000",
    ) -> str | None:
        """Download lua integration."""
        data = {
            "applianceSn": sn,
            "applianceType": hex(device_type),
            "applianceMFCode": manufacturer_code,
            "version": "0",
            "iotAppId": self._app_id,
        }
        fnm = None
        if (
            response := await self._api_request(
                endpoint="/v1/appliance/protocol/lua/luaGet",
                data=data,
            )
        ) and (metadata := self._get_lua_download_metadata(path, response, sn)):
            url, file_path = metadata
            res = await self._session.get(url, timeout=ClientTimeout(10))
            if res.status == HTTPStatus.OK:
                lua = await res.text()
                if lua:
                    stream = (
                        'local bit = require "bit"\n'
                        + self._security.aes_decrypt_with_fixed_key(lua)
                    )
                    stream = stream.replace("\r\n", "\n")
                    fnm = file_path
                    async with aiofiles.open(fnm, "w") as fp:
                        await fp.write(stream)
        return str(fnm) if fnm else None

    async def download_plugin(
        self,
        path: str,
        device_type: int,
        sn: str,
    ) -> str | None:
        """Download lua integration."""
        data = self._make_general_data()
        data.update(
            {
                "clientVersion": "201",
                "match": "1",
                "applianceList": [
                    {
                        "appModel": sn[9:17],
                        "appType": hex(device_type),
                        "modelNumber": "0",
                    },
                ],
            },
        )
        fnm = None
        if response := await self._api_request(
            endpoint="/v1/plugin/update/getplugin",
            data=data,
        ):
            # get file name from url
            _LOGGER.debug("response: %s, type: %s", response, type(response))
            file_name = response["list"][0]["url"].split("/")[-1]
            # download plugin from url
            res = await self._session.get(response["list"][0]["url"])
            if res.status == HTTPStatus.OK:
                # get the file content in binary mode
                plugin = await res.read()
                if plugin:
                    fnm = f"{path}/{file_name}"
                    async with aiofiles.open(fnm, "wb") as fp:
                        await fp.write(plugin)
        return str(fnm) if fnm else None


class SmartHomeCloud(MideaCloud):
    """MSmart Home Cloud."""

    def __init__(
        self,
        cloud_name: str,
        session: ClientSession,
        account: str,
        password: str,
    ) -> None:
        """Initialize MSmart Cloud."""
        cloud_data = cast("dict[str, Any]", SUPPORTED_CLOUDS[cloud_name])
        super().__init__(
            session=session,
            security=MSmartCloudSecurity(
                login_key=cloud_data["app_key"],
                iot_key=cloud_data["iot_key"],
                hmac_key=cloud_data["hmac_key"],
            ),
            app_id=cloud_data["app_id"],
            app_key=cloud_data["app_key"],
            account=account,
            password=password,
            api_url=cloud_data["api_url"],
        )
        self._auth_base = base64.b64encode(
            f"{self._app_key}:{cloud_data['iot_key']}".encode(
                "ascii",
            ),
        ).decode("ascii")

    def _make_general_data(self) -> dict[str, Any]:
        return {
            "src": self._app_id,
            "format": "2",
            "stamp": datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S"),
            "platformId": "1",
            "deviceId": self._device_id,
            "reqId": token_hex(16),
            "uid": self._uid,
            "clientType": "1",
            "appId": self._app_id,
            "language": "en_US",
        }

    async def _api_request(
        self,
        endpoint: str,
        data: dict[str, Any],
        header: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        header = header or {}
        header.update(
            {"x-recipe-app": self._app_id, "authorization": f"Basic {self._auth_base}"},
        )

        return await super()._api_request(endpoint, data, header)

    async def _re_route(self) -> None:
        data = self._make_general_data()
        data.update({"userType": "0", "userName": f"{self._account}"})
        if (
            response := await self._api_request(
                endpoint="/v1/multicloud/platform/user/route",
                data=data,
            )
        ) and (api_url := response.get("masUrl")):
            self._api_url = api_url

    async def login(self) -> bool:
        """Authenticate to MSmart Cloud."""
        await self._re_route()
        if login_id := await self._get_login_id():
            self._login_id = login_id
            iot_data = self._make_general_data()
            iot_data.pop("uid")
            stamp = datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S")
            iot_data.update(
                {
                    "iampwd": self._security.encrypt_iam_password(
                        self._login_id,
                        self._password,
                    ),
                    "loginAccount": self._account,
                    "password": self._security.encrypt_password(
                        self._login_id,
                        self._password,
                    ),
                    "stamp": stamp,
                },
            )
            data = {
                "iotData": iot_data,
                "data": {
                    "appKey": self._app_key,
                    "deviceId": self._device_id,
                    "platform": "2",
                },
                "stamp": stamp,
            }
            if response := await self._api_request(
                endpoint="/mj/user/login",
                data=data,
            ):
                self._uid = response["uid"]
                self._access_token = response["mdata"]["accessToken"]
                self._security.set_aes_keys(
                    response["accessToken"],
                    response["randomData"],
                )
                return True
        _LOGGER.warning("SmartHome Cloud login failed for device %s", self._device_id)
        return False

    async def list_appliances(
        self,
        home_id: str | None,  # noqa: ARG002
    ) -> dict[int, dict[str, Any]] | None:
        """List MSmart Cloud Devices."""
        data = self._make_general_data()
        if response := await self._api_request(
            endpoint="/v1/appliance/user/list/get",
            data=data,
        ):
            appliances = {}
            for appliance in response["list"]:
                try:
                    model_number = int(appliance.get("modelNumber", 0))
                except ValueError:
                    model_number = 0
                device_info = {
                    "name": appliance.get("name"),
                    "type": int(appliance.get("type"), 16),
                    "sn": self._security.aes_decrypt(appliance.get("sn") or ""),
                    "sn8": "",
                    "model_number": model_number,
                    "manufacturer_code": appliance.get("enterpriseCode", "0000"),
                    "model": "",
                    "online": appliance.get("onlineStatus") == "1",
                }
                serial_num = device_info.get("sn")
                device_info["sn8"] = (
                    serial_num[9:17]
                    if (serial_num and len(serial_num) > SN8_MIN_SERIAL_LENGTH)
                    else ""
                )
                device_info["model"] = device_info.get("sn8")
                appliances[int(appliance["id"])] = device_info
            return appliances
        return None

    async def download_lua(
        self,
        path: str,
        device_type: int,
        sn: str,
        model_number: str | None = None,
        manufacturer_code: str = "0000",
    ) -> str | None:
        """Download lua integration."""
        data = self._make_general_data()
        data.update(
            {
                "applianceMFCode": manufacturer_code,
                "applianceType": hex(device_type),
                "applianceSn": self._security.aes_encrypt_with_fixed_key(
                    sn.encode("ascii"),
                ).hex(),
                "version": "0",
                "encryptedType": "2",
            },
        )
        if model_number is not None:
            data["modelNumber"] = model_number
        fnm = None
        if (
            response := await self._api_request(
                endpoint="/v2/luaEncryption/luaGet",
                data=data,
            )
        ) and (metadata := self._get_lua_download_metadata(path, response, sn)):
            url, file_path = metadata
            res = await self._session.get(url, timeout=ClientTimeout(10))
            if res.status == HTTPStatus.OK:
                lua = await res.text()
                if lua:
                    stream = (
                        'local bit = require "bit"\n'
                        + self._security.aes_decrypt_with_fixed_key(lua)
                    )
                    stream = stream.replace("\r\n", "\n")
                    fnm = file_path
                    async with aiofiles.open(fnm, "w") as fp:
                        await fp.write(stream)
        return str(fnm) if fnm else None

    async def download_plugin(
        self,
        path: str,
        device_type: int,
        sn: str,
    ) -> str | None:
        """Download lua integration."""
        data = self._make_general_data()
        data.update(
            {
                "clientVersion": "0",
                "applianceList": [
                    {
                        "appModel": sn[9:17],
                        "appType": hex(device_type),
                        "modelNumber": "0",
                    },
                ],
            },
        )
        fnm = None
        if response := await self._api_request(
            endpoint="/v1/plugin/update/overseas/get",
            data=data,
        ):
            # get file name from url
            _LOGGER.debug("response: %s, type: %s", response, type(response))
            file_name = response["result"][0]["url"].split("/")[-1]
            # download plugin from url
            res = await self._session.get(response["result"][0]["url"])
            if res.status == HTTPStatus.OK:
                # get the file content in binary mode
                plugin = await res.read()
                if plugin:
                    fnm = f"{path}/{file_name}"
                    async with aiofiles.open(fnm, "wb") as fp:
                        await fp.write(plugin)
        return str(fnm) if fnm else None


class MideaAirCloud(MideaCloud):
    """Midea Air Cloud."""

    def __init__(
        self,
        cloud_name: str,
        session: ClientSession,
        account: str,
        password: str,
        security: CloudSecurity | None = None,
    ) -> None:
        """Initialize Midea Air Cloud."""
        cloud_data = cast("dict[str, Any]", SUPPORTED_CLOUDS[cloud_name])
        super().__init__(
            session=session,
            security=security or MideaAirSecurity(login_key=cloud_data["app_key"]),
            app_id=cloud_data["app_id"],
            app_key=cloud_data["app_key"],
            account=account,
            password=password,
            api_url=cloud_data["api_url"],
        )
        self._session_id: str | None = None

    def _make_general_data(self) -> dict[str, Any]:
        data = {
            "src": self._app_id,
            "format": "2",
            "stamp": datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S"),
            "deviceId": self._device_id,
            "reqId": token_hex(16),
            "clientType": "1",
            "appId": self._app_id,
        }
        if self._session_id is not None:
            data.update({"sessionId": self._session_id})
        return data

    async def _api_request(
        self,
        endpoint: str,
        data: dict[str, Any],
        header: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        header = header or {}
        url = self._api_url + endpoint

        sign = self._security.sign(url, data, "")
        data.update({"sign": sign})
        if self._uid is not None:
            header.update({"uid": self._uid})
        if self._access_token is not None:
            header.update({"accessToken": self._access_token})
        # Track parse success separately: a reply that never arrived must not be
        # confused with a cloud that genuinely returns errorCode -1, so use None
        # for the absent-reply case rather than a cloud-controlled sentinel code.
        response: dict | None = None
        for _ in range(3):
            try:
                async with self._api_lock:
                    r = await self._session.request(
                        "POST",
                        url,
                        headers=header,
                        data=data,
                        timeout=ClientTimeout(10),
                    )
                    raw = await r.read()
                    _LOGGER.debug(
                        "Midea cloud API url: %s, \n data: %s, \n response: %s",
                        url,
                        _redact_data(str(data)),
                        _redact_data(str(raw)),
                    )
                    response = json.loads(raw)
                    break
            except (TimeoutError, ClientConnectionError, json.JSONDecodeError) as e:
                _LOGGER.warning(
                    "Midea cloud API error, url: %s, error: %s",
                    url,
                    repr(e),
                )
        if response is None:
            # No reply arrived after all retries; already logged above.
            return None
        error_code = int(response["errorCode"])
        if error_code == 0:
            if "result" in response:
                return cast("dict[str, Any]", response["result"])
            # The legacy lua endpoint returns its payload under "data" instead
            # of "result"; fall back to it so download_lua can read the url.
            if "data" in response:
                return cast("dict[str, Any]", response["data"])
        else:
            # Surface the cloud's own error for every parsed non-zero code. The
            # legacy appsmb.com backend now answers getToken with 9999 "system
            # error" for NetHome Plus / Midea Air / Ariston accounts: Midea
            # retired that service and this backend has no v2 endpoint to fall
            # back to, so the device must be re-paired under a SmartHome or
            # Meiju account instead.
            _LOGGER.warning(
                "Midea Air cloud API %s returned error %s: %s",
                endpoint,
                error_code,
                response.get("msg", ""),
            )
        return None

    async def login(self) -> bool:
        """Authenticate to Midea Air Cloud."""
        if login_id := await self._get_login_id():
            self._login_id = login_id
            data = self._make_general_data()
            data.update(
                {
                    "loginAccount": self._account,
                    "password": self._security.encrypt_password(
                        self._login_id,
                        self._password,
                    ),
                },
            )
            if response := await self._api_request(
                endpoint="/v1/user/login",
                data=data,
            ):
                self._access_token = response["accessToken"]
                self._uid = response["userId"]
                self._session_id = response["sessionId"]
                return True
        _LOGGER.warning("Midea Air Cloud login failed for device %s", self._device_id)
        return False

    async def list_appliances(
        self,
        home_id: str | None,  # noqa: ARG002
    ) -> dict[int, dict[str, Any]] | None:
        """List Midea Air devices."""
        data = self._make_general_data()
        if response := await self._api_request(
            endpoint="/v1/appliance/user/list/get",
            data=data,
        ):
            appliances = {}
            for appliance in response["list"]:
                try:
                    model_number = int(appliance.get("modelNumber", 0))
                except ValueError:
                    model_number = 0
                device_info = {
                    "name": appliance.get("name"),
                    "type": int(appliance.get("type"), 16),
                    "sn": appliance.get("sn"),
                    "sn8": "",
                    "model_number": model_number,
                    "manufacturer_code": appliance.get("enterpriseCode", "0000"),
                    "model": "",
                    "online": appliance.get("onlineStatus") == "1",
                }
                serial_num = device_info.get("sn")
                device_info["sn8"] = (
                    serial_num[9:17]
                    if (serial_num and len(serial_num) > SN8_MIN_SERIAL_LENGTH)
                    else ""
                )
                device_info["model"] = device_info.get("sn8")
                appliances[int(appliance["id"])] = device_info
            return appliances
        return None

    def _decrypt_appliance_lua(self, lua: str, sn: str) -> str | None:
        """Decrypt a downloaded appliance lua file.

        The current ``luaGetCbc`` endpoint serves AES-128-CBC content, while
        the legacy ``luaGet`` endpoint served AES-128-ECB. Try the current CBC
        scheme first and fall back to the legacy ECB scheme so a file from
        either endpoint decrypts correctly.
        """
        security = cast("MideaAirSecurity", self._security)
        try:
            return security.decrypt_appliance_lua_cbc(lua)
        except (ValueError, UnicodeDecodeError) as cbc_error:
            try:
                return security.decrypt_appliance_lua(lua)
            except (ValueError, UnicodeDecodeError) as ecb_error:
                _LOGGER.warning(
                    "Failed to decrypt lua for appliance %s (cbc: %s, ecb: %s)",
                    sn,
                    cbc_error,
                    ecb_error,
                )
                return None

    async def _fetch_lua_file(self, url: str, sn: str, endpoint: str) -> str | None:
        """Download the lua file body, swallowing transport errors.

        A failed download returns ``None`` so :meth:`download_lua` can fall
        back to the next endpoint instead of propagating the error.
        """
        try:
            res = await self._session.get(url, timeout=ClientTimeout(10))
            if res.status != HTTPStatus.OK:
                return None
            return cast("str", await res.text())
        except (ClientError, TimeoutError) as e:
            _LOGGER.warning(
                "Failed to download lua for appliance %s from %s: %s",
                sn,
                endpoint,
                e,
            )
            return None

    async def _download_lua_from_endpoint(
        self,
        endpoint: str,
        path: str,
        data: dict[str, Any],
        sn: str,
    ) -> str | None:
        """Request lua metadata from one endpoint and download the file.

        ``_api_request`` adds a ``sign`` entry to ``data`` derived from its
        current contents, so each attempt is given a fresh copy to avoid
        signing over a previous attempt's ``sign`` (which the backend rejects
        with "Sign illegal").
        """
        response = await self._api_request(endpoint=endpoint, data=dict(data))
        if not response:
            return None
        metadata = self._get_lua_download_metadata(path, response, sn)
        if not metadata:
            return None
        url, file_path = metadata
        lua = await self._fetch_lua_file(url, sn, endpoint)
        if not lua:
            return None
        decrypted_lua = self._decrypt_appliance_lua(lua, sn)
        if decrypted_lua is None:
            return None
        stream = ('local bit = require "bit"\n' + decrypted_lua).replace("\r\n", "\n")
        async with aiofiles.open(file_path, "w") as fp:
            await fp.write(stream)
        return str(file_path)

    async def download_lua(
        self,
        path: str,
        device_type: int,
        sn: str,
        model_number: str | None = None,  # noqa: ARG002
        manufacturer_code: str = "0000",
    ) -> str | None:
        """Download lua integration.

        The current app requests lua files from the ``luaGetCbc`` endpoint
        (AES-128-CBC), while older firmware used the plain ``luaGet`` endpoint
        (AES-128-ECB). Try the current endpoint first and fall back to the
        legacy one; the file served by either is decrypted by
        :meth:`_decrypt_appliance_lua`.
        """
        data = self._make_general_data()
        data.update(
            {
                "applianceSn": sn,
                "applianceType": hex(device_type),
                "applianceMFCode": manufacturer_code,
                "version": "0",
            },
        )
        for endpoint in (
            "/v1/appliance/protocol/lua/luaGetCbc",
            "/v1/appliance/protocol/lua/luaGet",
        ):
            fnm = await self._download_lua_from_endpoint(endpoint, path, data, sn)
            if fnm:
                return fnm
        return None


class TSmartLifeCloud(SmartHomeCloud):
    """TSmartLife cloud (Toshiba oversea-market app).

    See https://github.com/wuwentao/midea_ac_lan/issues/364 for the full
    investigation. Reuses SmartHomeCloud's login/getToken flow unchanged --
    the confirmed real api_url (see SUPPORTED_CLOUDS["TSmartLife"] above)
    matches SmartHomeCloud's URL/path convention. The maintainer has
    confirmed any v1/v2 getToken variant is acceptable; the only goal is a
    working LAN V3 token for device type 0xCA.

    Live-verified, not just structurally plausible: with these exact
    app_id/app_key/iot_key/hmac_key values, this unmodified class has
    successfully logged in, listed appliances, and retrieved a working
    LAN V3 token/key for a real production Toshiba GR-RF900WI-PMV(06)-MG
    fridge -- see https://github.com/jaspweowaale/toshiba-tsmartlife-local
    for the companion tool that does this and the full verification
    write-up. download_lua/download_plugin are inherited from SmartHomeCloud
    but have NOT been live-verified against the real TSmartLife cloud
    (only against mocked responses, see tests/cloud_test.py) -- a
    separate, narrower, still-open gap, distinct from login/
    list_appliances/get_cloud_keys above.

    SUPPORTED_CLOUDS["TSmartLife"]'s app_id/app_key/iot_key/hmac_key are
    the real, published, shared app-level constants (see that entry's
    own comment for the classification and source). The __init__ guard
    below still refuses to construct if they were ever blanked out again
    (e.g. a fork for a different app variant), so an incomplete
    "TSmartLife" config fails immediately with a clear message instead
    of attempting a doomed login with empty credentials.
    """

    def __init__(
        self,
        cloud_name: str,
        session: ClientSession,
        account: str,
        password: str,
    ) -> None:
        """Initialize TSmartLife cloud."""
        cloud_data = cast("dict[str, Any]", SUPPORTED_CLOUDS[cloud_name])
        if not cloud_data.get("app_id") or not cloud_data.get("app_key"):
            raise ElementMissing(
                "TSmartLife cloud credentials (app_id/app_key) are unknown "
                "and must be supplied before this cloud can be used -- see "
                "https://github.com/wuwentao/midea_ac_lan/issues/364. "
                "Refusing to initialize with blank credentials.",
            )
        super().__init__(
            cloud_name=cloud_name,
            session=session,
            account=account,
            password=password,
        )

    async def get_cloud_keys(self, appliance_id: int) -> dict[int, dict[str, Any]]:
        """Get keys for device, trying the v2 endpoint before falling back to v1.

        Found both `/v1/iot/secure/getToken` and `/v2/iot/secure/getToken`
        as literal strings in the real TSmartLife APK, plus named
        constants for both (`URL_IOT_SECURE_GET_TOKEN`/`_V2`) -- with no
        confirmed call-site evidence for either. This class's own
        docstring already states any v1/v2 variant is acceptable, so this
        tries v2 first (matching the native `{"applianceCodes": [`
        list-form template found in the app's protection SDK) and falls
        back to the inherited v1 implementation when v2 yields nothing --
        the same safety-net shape as MeijuCloud.get_cloud_keys(), minus
        the `homegroupId` field: TSmartLife's real list-home endpoint is
        unconfirmed (SmartHomeCloud never overrides the inherited
        MideaCloud.list_home() static placeholder), so sending a
        homegroupId derived from it would be unverified invention, not a
        justified fix. (The real device that live-verified login/
        list_appliances/get_cloud_keys above used the v1 path, inherited
        unmodified -- this v2-first override is a defensive completeness
        addition for any TSmartLife deployment whose backend might only
        answer v2, not something the live verification itself exercised.)
        """
        result: dict[int, dict[str, Any]] = {}
        for method in [1, 2]:
            udp_id = self._security.get_udp_id(appliance_id, method)
            data = self._make_general_data()
            data.update({"udpid": udp_id, "applianceCodes": [str(appliance_id)]})
            try:
                response = await self._api_request(
                    endpoint="/v2/iot/secure/getToken",
                    data=data,
                )
            except (KeyError, TypeError, ValueError):
                response = None
            if keys := _parse_token_list(response, udp_id):
                result[method] = keys
        if not result:
            _LOGGER.debug(
                "v2 getToken returned no keys for appliance_id %s, "
                "falling back to the v1 endpoint",
                appliance_id,
            )
            return await super().get_cloud_keys(appliance_id)
        return result


class ToshibaIOLife(MideaAirCloud):
    """Toshiba IOLife cloud."""

    def __init__(
        self,
        cloud_name: str,
        session: ClientSession,
        account: str,
        password: str,
    ) -> None:
        """Initialize Toshiba IOLife cloud."""
        cloud_data = cast("dict[str, Any]", SUPPORTED_CLOUDS[cloud_name])
        super().__init__(
            cloud_name=cloud_name,
            session=session,
            account=account,
            password=password,
            security=ToshibaIOLifeSecurity(cloud_data["app_key"]),
        )
        self._app_version: str = cloud_data["app_version"]
        self._manufacturer_code: str = cloud_data["manufacturer_code"]

    def _decrypt_sn(self, encrypted_sn: str) -> str:
        """Decrypt SN blob from home/page/list/info."""
        if not self._access_token or not encrypted_sn:
            return ""
        try:
            return cast("ToshibaIOLifeSecurity", self._security).decrypt_appliance_sn(
                encrypted_sn,
                self._access_token,
            )
        except (ValueError, UnicodeDecodeError):
            _LOGGER.debug("Failed to decrypt appliance SN")
            return ""

    async def list_appliances(
        self,
        home_id: str | None = None,  # noqa: ARG002
    ) -> dict[int, dict[str, Any]]:
        """Get Toshiba IOLife devices."""
        data = self._make_general_data()
        data["appVersion"] = self._app_version
        # home/page/list/info returns result as a bare list, not {list: [...]}
        page_list: Any = await self._api_request(
            endpoint="/v1/appliance/user/home/page/list/info",
            data=data,
        )
        if not isinstance(page_list, list):
            return {}

        appliances: dict[int, dict[str, Any]] = {}
        for appliance in page_list:
            if not isinstance(appliance, Mapping):
                continue
            # Skip virtual/batch devices.
            if (
                appliance.get("type") == "0x_BATCH_AC"
                or appliance.get("id") == "virtual_ag_0xAC"
            ):
                continue
            try:
                device_id = int(appliance["id"])
                device_type = int(appliance["type"], 16)
            except (KeyError, TypeError, ValueError):
                _LOGGER.debug("Skipping malformed appliance entry: %s", appliance)
                continue
            try:
                model_number = int(appliance.get("modelNumber", 0))
            except (TypeError, ValueError):
                model_number = 0
            sn = self._decrypt_sn(str(appliance.get("sn") or ""))
            sn8 = sn[9:17] if len(sn) > SN8_MIN_SERIAL_LENGTH else ""
            appliances[device_id] = {
                "name": appliance.get("name"),
                "type": device_type,
                "sn": sn,
                "sn8": sn8,
                "model_number": model_number,
                "manufacturer_code": appliance.get(
                    "enterpriseCode",
                    self._manufacturer_code,
                ),
                "model": sn8,
                "online": appliance.get("onlineStatus") == "1",
            }

        return appliances


def get_midea_cloud(
    cloud_name: str,
    session: ClientSession,
    account: str,
    password: str,
) -> MideaCloud:
    """Get Midea Cloud implementation."""
    if cloud_name not in SUPPORTED_CLOUDS:
        raise ElementMissing(
            f"Unsupported Cloud specified: {cloud_name}",
        )

    cloud_data = cast("dict[str, Any]", SUPPORTED_CLOUDS[cloud_name])
    return cast(
        "MideaCloud",
        globals()[cloud_data["class_name"]](
            cloud_name=cloud_name,
            session=session,
            account=account,
            password=password,
        ),
    )
